<?php
/**
 * Product Manager Backend
 * Mengelola produk dalam satu file JSON per kategori layanan
 * 
 * Struktur:
 * data/produk/
 * ├── katalog-filter.json
 * ├── katalog-plumbing.json
 * ├── katalog-pompa-air.json
 * └── katalog-water-heater.json
 */

class ProductManager {
    private $produk_dir = '../data/produk/';
    private $kategori_layanan = [
        'filter-air' => 'katalog-filter.json',
        'plumbing' => 'katalog-plumbing.json',
        'pompa-air' => 'katalog-pompa-air.json',
        'water-heater' => 'katalog-water-heater.json',
        'pipa-mampet' => 'katalog-pipa-mampet.json',
        'perbaikan' => 'katalog-perbaikan.json'
    ];
    
    public function __construct() {
        // Ensure produk directory exists
        if (!is_dir($this->produk_dir)) {
            mkdir($this->produk_dir, 0755, true);
        }
    }
    
    /**
     * Get file path for kategori layanan
     */
    private function getFilePath($kategori) {
        if (!isset($this->kategori_layanan[$kategori])) {
            throw new Exception("Kategori layanan tidak valid: $kategori");
        }
        return $this->produk_dir . $this->kategori_layanan[$kategori];
    }
    
    /**
     * Load products from JSON file
     */
    public function loadProducts($kategori) {
        $file_path = $this->getFilePath($kategori);
        
        if (!file_exists($file_path)) {
            // Create empty file with default structure
            $default_data = [
                'kategori' => $kategori,
                'nama_kategori' => $this->getKategoriName($kategori),
                'deskripsi' => 'Katalog produk ' . $this->getKategoriName($kategori),
                'produk' => []
            ];
            $this->saveProducts($kategori, $default_data);
            return $default_data;
        }
        
        $content = file_get_contents($file_path);
        $data = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Error parsing JSON: " . json_last_error_msg());
        }
        
        return $data;
    }
    
    /**
     * Save products to JSON file
     */
    public function saveProducts($kategori, $data) {
        $file_path = $this->getFilePath($kategori);
        
        $json_content = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Error encoding JSON: " . json_last_error_msg());
        }
        
        $result = file_put_contents($file_path, $json_content);
        
        if ($result === false) {
            throw new Exception("Error saving file: $file_path");
        }
        
        return true;
    }
    
    /**
     * Create new product
     */
    public function createProduct($kategori, $product_data) {
        $data = $this->loadProducts($kategori);
        
        // Generate unique ID
        $product_data['id'] = $this->generateProductId($kategori);
        
        // Set default values
        $product_data['created_at'] = date('Y-m-d H:i:s');
        $product_data['updated_at'] = date('Y-m-d H:i:s');
        
        // Validate required fields
        $this->validateProduct($product_data);
        
        // Add to products array
        $data['produk'][] = $product_data;
        
        // Save back to file
        $this->saveProducts($kategori, $data);
        
        return $product_data;
    }
    
    /**
     * Update existing product
     */
    public function updateProduct($kategori, $product_id, $product_data) {
        $data = $this->loadProducts($kategori);
        
        $product_index = $this->findProductIndex($data['produk'], $product_id);
        
        if ($product_index === -1) {
            throw new Exception("Product not found: $product_id");
        }
        
        // Preserve ID and created_at
        $product_data['id'] = $product_id;
        $product_data['created_at'] = $data['produk'][$product_index]['created_at'];
        $product_data['updated_at'] = date('Y-m-d H:i:s');
        
        // Validate product data
        $this->validateProduct($product_data);
        
        // Update product
        $data['produk'][$product_index] = $product_data;
        
        // Save back to file
        $this->saveProducts($kategori, $data);
        
        return $product_data;
    }
    
    /**
     * Delete product
     */
    public function deleteProduct($kategori, $product_id) {
        $data = $this->loadProducts($kategori);
        
        $product_index = $this->findProductIndex($data['produk'], $product_id);
        
        if ($product_index === -1) {
            throw new Exception("Product not found: $product_id");
        }
        
        // Remove product
        array_splice($data['produk'], $product_index, 1);
        
        // Save back to file
        $this->saveProducts($kategori, $data);
        
        return true;
    }
    
    /**
     * Get product by ID
     */
    public function getProduct($kategori, $product_id) {
        $data = $this->loadProducts($kategori);
        
        foreach ($data['produk'] as $product) {
            if ($product['id'] === $product_id) {
                return $product;
            }
        }
        
        return null;
    }
    
    /**
     * Get all products from kategori
     */
    public function getAllProducts($kategori) {
        $data = $this->loadProducts($kategori);
        return $data['produk'];
    }
    
    /**
     * Get all products from all categories
     */
    public function getAllProductsFromAllCategories() {
        $all_products = [];
        
        foreach (array_keys($this->kategori_layanan) as $kategori) {
            try {
                $products = $this->getAllProducts($kategori);
                $all_products = array_merge($all_products, $products);
            } catch (Exception $e) {
                // Skip if file doesn't exist or has errors
                continue;
            }
        }
        
        return $all_products;
    }
    
    /**
     * Find product index by ID
     */
    private function findProductIndex($products, $product_id) {
        foreach ($products as $index => $product) {
            if ($product['id'] === $product_id) {
                return $index;
            }
        }
        return -1;
    }
    
    /**
     * Generate unique product ID
     */
    private function generateProductId($kategori) {
        $data = $this->loadProducts($kategori);
        $existing_ids = array_column($data['produk'], 'id');
        
        $prefix = strtoupper(str_replace('-', '', $kategori));
        $counter = 1;
        
        do {
            $new_id = $prefix . '-' . str_pad($counter, 3, '0', STR_PAD_LEFT);
            $counter++;
        } while (in_array($new_id, $existing_ids));
        
        return $new_id;
    }
    
    /**
     * Validate product data
     */
    private function validateProduct($product_data) {
        $required_fields = ['nama', 'deskripsi', 'harga'];
        
        foreach ($required_fields as $field) {
            if (empty($product_data[$field])) {
                throw new Exception("Field '$field' is required");
            }
        }
        
        // Validate harga structure
        if (isset($product_data['harga']) && is_array($product_data['harga'])) {
            foreach ($product_data['harga'] as $cabang => $harga_data) {
                if (!isset($harga_data['harga']) || !is_numeric($harga_data['harga'])) {
                    throw new Exception("Invalid harga for cabang: $cabang");
                }
            }
        }
        
        return true;
    }
    
    /**
     * Get kategori name
     */
    private function getKategoriName($kategori) {
        $names = [
            'filter-air' => 'Filter Air',
            'plumbing' => 'Plumbing',
            'pompa-air' => 'Pompa Air',
            'water-heater' => 'Water Heater',
            'pipa-mampet' => 'Pipa Mampet',
            'perbaikan' => 'Perbaikan'
        ];
        
        return $names[$kategori] ?? ucfirst(str_replace('-', ' ', $kategori));
    }
    
    /**
     * Get available categories
     */
    public function getAvailableCategories() {
        return array_keys($this->kategori_layanan);
    }
    
    /**
     * Get kategori info
     */
    public function getKategoriInfo() {
        $info = [];
        foreach ($this->kategori_layanan as $kategori => $filename) {
            $info[$kategori] = [
                'nama' => $this->getKategoriName($kategori),
                'filename' => $filename,
                'filepath' => $this->produk_dir . $filename,
                'exists' => file_exists($this->produk_dir . $filename)
            ];
        }
        return $info;
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $manager = new ProductManager();
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'create':
                $kategori = $_POST['kategori'] ?? '';
                $product_data = json_decode($_POST['product_data'], true);
                $result = $manager->createProduct($kategori, $product_data);
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            case 'update':
                $kategori = $_POST['kategori'] ?? '';
                $product_id = $_POST['product_id'] ?? '';
                $product_data = json_decode($_POST['product_data'], true);
                $result = $manager->updateProduct($kategori, $product_id, $product_data);
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            case 'delete':
                $kategori = $_POST['kategori'] ?? '';
                $product_id = $_POST['product_id'] ?? '';
                $result = $manager->deleteProduct($kategori, $product_id);
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            case 'get':
                $kategori = $_POST['kategori'] ?? '';
                $product_id = $_POST['product_id'] ?? '';
                $result = $manager->getProduct($kategori, $product_id);
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            case 'list':
                $kategori = $_POST['kategori'] ?? '';
                if ($kategori) {
                    $result = $manager->getAllProducts($kategori);
                } else {
                    $result = $manager->getAllProductsFromAllCategories();
                }
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            case 'categories':
                $result = $manager->getKategoriInfo();
                echo json_encode(['success' => true, 'data' => $result]);
                break;
                
            default:
                echo json_encode(['success' => false, 'error' => 'Invalid action']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager - BersihPipa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <h1 class="text-3xl font-bold text-gray-900 mb-8">Product Manager - BersihPipa</h1>
            
            <!-- Category Tabs -->
            <div class="mb-8">
                <div class="border-b border-gray-200">
                    <nav class="-mb-px flex space-x-8" id="category-tabs">
                        <!-- Tabs will be loaded here -->
                    </nav>
                </div>
            </div>
            
            <!-- Product List -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                <div class="px-6 py-4 border-b border-gray-200">
                    <div class="flex justify-between items-center">
                        <h2 class="text-lg font-semibold text-gray-900" id="category-title">Products</h2>
                        <button onclick="openCreateModal()" class="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition-colors">
                            <i data-lucide="plus" class="w-4 h-4 inline mr-2"></i>
                            Add Product
                        </button>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price Range</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Updated</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200" id="products-table">
                            <!-- Products will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Create/Edit Modal -->
    <div id="product-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-screen overflow-y-auto">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900" id="modal-title">Add Product</h3>
                </div>
                
                <form id="product-form" class="p-6">
                    <input type="hidden" id="product-id" name="product_id">
                    <input type="hidden" id="current-kategori" name="kategori">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Product Name</label>
                            <input type="text" id="product-name" name="nama" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500" required>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                            <textarea id="product-description" name="deskripsi" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500" required></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                            <select id="product-category" name="kategori" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500" required>
                                <!-- Options will be loaded -->
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <select id="product-status" name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="draft">Draft</option>
                            </select>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Images (one per line)</label>
                            <textarea id="product-images" name="gambar" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500" placeholder="image1.jpg&#10;image2.jpg&#10;image3.jpg"></textarea>
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Pricing (JSON format)</label>
                            <textarea id="product-pricing" name="harga" rows="6" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-mono text-sm" placeholder='{
  "malang": {
    "harga": 150000,
    "gratis_ongkir": true,
    "estimasi": "1-2 hari"
  },
  "surabaya": {
    "harga": 180000,
    "gratis_ongkir": false,
    "estimasi": "2-3 hari"
  }
}' required></textarea>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeModal()" class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors">
                            Save Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        let currentCategory = 'filter-air';
        let categories = {};
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadCategories();
            loadProducts(currentCategory);
        });
        
        // Load categories
        async function loadCategories() {
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=categories'
                });
                
                const result = await response.json();
                if (result.success) {
                    categories = result.data;
                    renderCategoryTabs();
                    populateCategorySelect();
                }
            } catch (error) {
                console.error('Error loading categories:', error);
            }
        }
        
        // Render category tabs
        function renderCategoryTabs() {
            const tabsContainer = document.getElementById('category-tabs');
            tabsContainer.innerHTML = '';
            
            Object.keys(categories).forEach(kategori => {
                const tab = document.createElement('a');
                tab.href = '#';
                tab.className = `whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm ${kategori === currentCategory ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`;
                tab.textContent = categories[kategori].nama;
                tab.onclick = () => switchCategory(kategori);
                tabsContainer.appendChild(tab);
            });
        }
        
        // Switch category
        function switchCategory(kategori) {
            currentCategory = kategori;
            renderCategoryTabs();
            loadProducts(kategori);
            document.getElementById('category-title').textContent = categories[kategori].nama + ' Products';
        }
        
        // Load products
        async function loadProducts(kategori) {
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=list&kategori=${kategori}`
                });
                
                const result = await response.json();
                if (result.success) {
                    renderProducts(result.data);
                }
            } catch (error) {
                console.error('Error loading products:', error);
            }
        }
        
        // Render products table
        function renderProducts(products) {
            const tbody = document.getElementById('products-table');
            tbody.innerHTML = '';
            
            if (products.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            No products found in this category
                        </td>
                    </tr>
                `;
                return;
            }
            
            products.forEach(product => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50';
                
                const priceRange = getPriceRange(product.harga);
                const status = product.status || 'active';
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 h-10 w-10">
                                <img class="h-10 w-10 rounded-lg object-cover" src="${product.gambar && product.gambar[0] ? '/upload/katalog-filter/' + encodeURIComponent(product.gambar[0]) : '/placeholder.jpg'}" alt="${product.nama}">
                            </div>
                            <div class="ml-4">
                                <div class="text-sm font-medium text-gray-900">${product.nama}</div>
                                <div class="text-sm text-gray-500">${product.id}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${priceRange}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusClass(status)}">
                            ${status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${product.updated_at || 'N/A'}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onclick="editProduct('${product.id}')" class="text-teal-600 hover:text-teal-900 mr-3">Edit</button>
                        <button onclick="deleteProduct('${product.id}')" class="text-red-600 hover:text-red-900">Delete</button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // Get price range
        function getPriceRange(harga) {
            if (!harga || typeof harga !== 'object') return 'N/A';
            
            const prices = Object.values(harga).map(h => h.harga).filter(p => p);
            if (prices.length === 0) return 'N/A';
            
            const min = Math.min(...prices);
            const max = Math.max(...prices);
            
            return min === max ? 
                `Rp ${min.toLocaleString()}` : 
                `Rp ${min.toLocaleString()} - Rp ${max.toLocaleString()}`;
        }
        
        // Get status class
        function getStatusClass(status) {
            switch (status) {
                case 'active': return 'bg-green-100 text-green-800';
                case 'inactive': return 'bg-red-100 text-red-800';
                case 'draft': return 'bg-yellow-100 text-yellow-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        }
        
        // Open create modal
        function openCreateModal() {
            document.getElementById('modal-title').textContent = 'Add Product';
            document.getElementById('product-form').reset();
            document.getElementById('product-id').value = '';
            document.getElementById('current-kategori').value = currentCategory;
            document.getElementById('product-category').value = currentCategory;
            document.getElementById('product-modal').classList.remove('hidden');
        }
        
        // Edit product
        async function editProduct(productId) {
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=get&kategori=${currentCategory}&product_id=${productId}`
                });
                
                const result = await response.json();
                if (result.success && result.data) {
                    const product = result.data;
                    
                    document.getElementById('modal-title').textContent = 'Edit Product';
                    document.getElementById('product-id').value = product.id;
                    document.getElementById('current-kategori').value = currentCategory;
                    document.getElementById('product-name').value = product.nama;
                    document.getElementById('product-description').value = product.deskripsi;
                    document.getElementById('product-category').value = product.kategori || currentCategory;
                    document.getElementById('product-status').value = product.status || 'active';
                    document.getElementById('product-images').value = product.gambar ? product.gambar.join('\n') : '';
                    document.getElementById('product-pricing').value = JSON.stringify(product.harga, null, 2);
                    
                    document.getElementById('product-modal').classList.remove('hidden');
                }
            } catch (error) {
                console.error('Error loading product:', error);
            }
        }
        
        // Delete product
        async function deleteProduct(productId) {
            if (!confirm('Are you sure you want to delete this product?')) return;
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=delete&kategori=${currentCategory}&product_id=${productId}`
                });
                
                const result = await response.json();
                if (result.success) {
                    loadProducts(currentCategory);
                } else {
                    alert('Error deleting product: ' + result.error);
                }
            } catch (error) {
                console.error('Error deleting product:', error);
            }
        }
        
        // Close modal
        function closeModal() {
            document.getElementById('product-modal').classList.add('hidden');
        }
        
        // Populate category select
        function populateCategorySelect() {
            const select = document.getElementById('product-category');
            select.innerHTML = '';
            
            Object.keys(categories).forEach(kategori => {
                const option = document.createElement('option');
                option.value = kategori;
                option.textContent = categories[kategori].nama;
                select.appendChild(option);
            });
        }
        
        // Handle form submission
        document.getElementById('product-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const productId = formData.get('product_id');
            const kategori = formData.get('kategori');
            
            // Prepare product data
            const productData = {
                nama: formData.get('nama'),
                deskripsi: formData.get('deskripsi'),
                kategori: kategori,
                status: formData.get('status'),
                gambar: formData.get('gambar').split('\n').filter(img => img.trim()),
                harga: JSON.parse(formData.get('harga'))
            };
            
            try {
                const action = productId ? 'update' : 'create';
                const body = new URLSearchParams({
                    action: action,
                    kategori: kategori,
                    product_data: JSON.stringify(productData)
                });
                
                if (productId) {
                    body.append('product_id', productId);
                }
                
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: body.toString()
                });
                
                const result = await response.json();
                if (result.success) {
                    closeModal();
                    loadProducts(currentCategory);
                } else {
                    alert('Error saving product: ' + result.error);
                }
            } catch (error) {
                console.error('Error saving product:', error);
                alert('Error saving product');
            }
        });
        
        // Initialize Lucide icons
        lucide.createIcons();
    </script>
</body>
</html> 