<?php
// Footer Component - BersihPipa.com
?>
<footer class="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-16">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Company Info -->
            <div class="lg:col-span-2">
                <div class="flex items-center space-x-3 mb-6">
                    <img src="https://bersihpipa.com/wp-content/uploads/2025/02/2657-06.png" 
                         alt="BersihPipa.com" 
                         class="h-10 w-auto brightness-0 invert" 
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'">
                    <div class="hidden items-center space-x-3">
                        <div class="w-8 h-8 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                            <span class="text-white font-bold text-sm">B</span>
                        </div>
                        <div>
                            <span class="text-2xl font-bold">BersihPipa</span>
                            <p class="text-sm text-gray-400">Jasa Saluran Mampet</p>
                        </div>
                    </div>
                </div>
                <p class="text-gray-300 mb-6 leading-relaxed max-w-md">
                    Solusi terpercaya untuk detox pipa dan pembersihan saluran air dengan teknologi canggih. Melayani seluruh Jawa Timur dengan garansi hasil.
                </p>
                <div class="flex space-x-4">
                    <a href="https://instagram.com/fluksofficial" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       class="w-12 h-12 bg-gray-800 hover:bg-gradient-to-r hover:from-pink-500 hover:to-purple-600 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-110">
                        <i data-lucide="instagram" class="w-5 h-5"></i>
                    </a>
                    <a href="https://www.youtube.com/@fluksaqua" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       class="w-12 h-12 bg-gray-800 hover:bg-red-600 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-110">
                        <i data-lucide="youtube" class="w-5 h-5"></i>
                    </a>
                    <a href="https://wa.me/6281236937200" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       class="w-12 h-12 bg-gray-800 hover:bg-green-600 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-110">
                        <i data-lucide="phone" class="w-5 h-5"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div>
                <h3 class="text-xl font-bold mb-6 text-white">Quick Links</h3>
                <ul class="space-y-3">
                    <li><a href="https://www.bersihpipa.com" class="text-gray-300 hover:text-white transition-colors flex items-center group">
                        <i data-lucide="home" class="h-4 w-4 mr-2 group-hover:text-blue-400"></i>
                        Home
                    </a></li>
                    <li><a href="#layanan" onclick="scrollToSection('layanan-kami')" class="text-gray-300 hover:text-white transition-colors flex items-center group cursor-pointer">
                        <i data-lucide="wrench" class="h-4 w-4 mr-2 group-hover:text-blue-400"></i>
                        Layanan
                    </a></li>
                    <li><a href="#harga" onclick="scrollToSection('harga-paket')" class="text-gray-300 hover:text-white transition-colors flex items-center group cursor-pointer">
                        <i data-lucide="calculator" class="h-4 w-4 mr-2 group-hover:text-blue-400"></i>
                        Harga
                    </a></li>
                    <li><a href="#kontak" onclick="scrollToSection('kontak')" class="text-gray-300 hover:text-white transition-colors flex items-center group cursor-pointer">
                        <i data-lucide="phone" class="h-4 w-4 mr-2 group-hover:text-blue-400"></i>
                        Kontak
                    </a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div>
                <h3 class="text-xl font-bold mb-6 text-white">Kontak Kami</h3>
                <div class="space-y-4">
                    <div class="flex items-start space-x-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                            <i data-lucide="phone" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <p class="text-gray-400 text-sm">Telepon / WhatsApp</p>
                            <a href="tel:+6281236937200" class="text-white hover:text-blue-400 transition-colors font-semibold">
                                +62 812-3693-7200
                            </a>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                            <i data-lucide="mail" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <p class="text-gray-400 text-sm">Email</p>
                            <a href="mailto:flukswater@gmail.com" class="text-white hover:text-blue-400 transition-colors font-semibold">
                                flukswater@gmail.com
                            </a>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                            <i data-lucide="map-pin" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <p class="text-gray-400 text-sm">Alamat Kantor</p>
                            <a href="https://maps.google.com/?q=Jl.+Candi+Mendut+No+23B+Lowokwaru+Kota+Malang+Jawa+Timur" 
                               target="_blank" 
                               class="text-white hover:text-blue-400 transition-colors">
                                Jl. Candi Mendut No 23B<br>
                                Lowokwaru, Kota Malang<br>
                                Jawa Timur 65141
                            </a>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                            <i data-lucide="clock" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <p class="text-gray-400 text-sm">Jam Operasional</p>
                            <p class="text-white">
                                Senin - Sabtu: 08:00 - 17:00<br>
                                <span class="text-green-400 font-semibold">Layanan Darurat: 24/7</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service Areas -->
        <div class="border-t border-gray-700 mt-12 pt-8">
            <h4 class="text-lg font-bold text-white mb-4 text-center">Area Layanan</h4>
            <div class="flex flex-wrap justify-center gap-4 text-sm text-gray-300">
                <?php 
                $serviceAreas = ['Malang', 'Sidoarjo', 'Surabaya', 'Pasuruan', 'Probolinggo', 'Mojokerto', 'Blitar', 'Tulungagung', 'Kediri', 'Batu'];
                foreach($serviceAreas as $area): ?>
                <span class="bg-gray-800 px-3 py-1 rounded-full hover:bg-blue-600 transition-colors cursor-default">
                    <?= $area ?>
                </span>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Bottom Bar -->
        <div class="border-t border-gray-700 mt-8 pt-8 text-center">
            <div class="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                <p class="text-gray-400 text-sm">
                    © 2024 BersihPipa.com - FLUKS Water Treatment. All rights reserved.
                </p>
                <div class="flex items-center space-x-6 text-sm text-gray-400">
                    <a href="#" class="hover:text-white transition-colors">Privacy Policy</a>
                    <a href="#" class="hover:text-white transition-colors">Terms of Service</a>
                    <a href="#" class="hover:text-white transition-colors">Sitemap</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<button id="back-to-top" 
        onclick="scrollToTop()" 
        class="fixed bottom-24 right-6 w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 z-40 opacity-0 invisible">
    <i data-lucide="arrow-up" class="h-6 w-6 mx-auto"></i>
</button>

<script>
// Back to top button functionality
window.addEventListener('scroll', function() {
    const backToTopButton = document.getElementById('back-to-top');
    if (backToTopButton) {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.remove('opacity-0', 'invisible');
            backToTopButton.classList.add('opacity-100', 'visible');
        } else {
            backToTopButton.classList.add('opacity-0', 'invisible');
            backToTopButton.classList.remove('opacity-100', 'visible');
        }
    }
});
</script>
