<?php
/*
Template Name: BersihPipa.com - Product Detail PWA
*/
header('Content-Type: text/html; charset=UTF-8');

// Include helper files
require_once '../includes/product-helper.php';
require_once '../includes/cabang-selector.php';

// Get parameters from URL
$product_id = $_GET['id'] ?? 'FA001';
$selected_cabang = $_GET['cabang'] ?? 'malang';

// Validate cabang
$helper = new ProductHelper();
if (!$helper->isValidCabang($selected_cabang)) {
    $selected_cabang = $helper->getDefaultCabang();
}

// Load product data
$product = $helper->getProductById($product_id, $selected_cabang);
if (!$product) {
    header('Location: /');
    exit;
}

// Get data
$cabang_data = $helper->getCabangData($selected_cabang);
$price_data = $helper->getProductPrice($product_id, $selected_cabang);
$related_products = $helper->getRelatedProducts($product_id, 4);
$product_images = $helper->getProductImages($product);
$installment = $helper->calculateInstallment($price_data['harga'] ?? 0, 12);

$shipping = [
    'free_shipping' => $price_data['gratis_ongkir'] ?? true,
    'estimated_delivery' => $price_data['estimasi'] ?? '2-3 hari',
    'courier' => 'JNE, J&T, SiCepat'
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no,viewport-fit=cover">
    <meta name="theme-color" content="#0f766e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="BersihPipa Product">
    
    <title><?= htmlspecialchars($product['nama']) ?> - BersihPipa.com</title>
    <meta name="description" content="<?= htmlspecialchars($product['deskripsi']) ?>">
    
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5QG7XXWW');</script>
    <!-- End Google Tag Manager -->
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Jasa Detox dan Bersih Pipa Mampet - BersihPipa.com",
      "image": "https://filterairkota.com/wp-content/uploads/2025/05/bersihpipa-thumbnail.webp",
      "@id": "https://bersihpipa.com",
      "url": "https://bersihpipa.com",
      "telephone": "+62-812-3693-7200",
      "email": "flukswater@gmail.com",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Jl. Candi Mendut No 23B, Lowokwaru",
        "addressLocality": "Kota Malang",
        "addressRegion": "Jawa Timur",
        "postalCode": "65141",
        "addressCountry": "ID"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -7.940995,
        "longitude": 112.613579
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
          ],
          "opens": "08:00",
          "closes": "17:00"
        }
      ],
      "priceRange": "Rp 150.000/Kran",
      "description": "Layanan Detox & Bersih Pipa per kran tanpa bongkar – untuk rumah, kos, kantor, dan gedung besar. Teknologi modern, bergaransi, dan gratis konsultasi. Beroperasi di seluruh kota besar di Jawa Timur.",
      "sameAs": [
        "https://instagram.com/fluksofficial",
        "https://www.youtube.com/@fluksaqua"
      ],
      "areaServed": {
        "@type": "Place",
        "name": [
          "Malang", "Sidoarjo", "Blitar", "Mojokerto", "Batu", "Pasuruan",
          "Surabaya", "Kediri", "Probolinggo", "Jember", "Lumajang", "Bondowoso", "Situbondo", "Madiun", "Ngawi", "Magetan", "Nganjuk", "Tulungagung", "Trenggalek", "Ponorogo", "Bojonegoro", "Tuban", "Lamongan", "Gresik", "Pacitan"
        ]
      }
    }
    </script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Inter', 'system-ui', '-apple-system', 'sans-serif']
                    },
                    colors: {
                        primary: {
                            50: '#f0fdfa', 100: '#ccfbf1', 200: '#99f6e4', 300: '#5eead4',
                            400: '#2dd4bf', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e',
                            800: '#115e59', 900: '#134e4a',
                        },
                        surface: {
                            50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 300: '#cbd5e1',
                            400: '#94a3b8', 500: '#64748b', 600: '#475569', 700: '#334155',
                            800: '#1e293b', 900: '#0f172a',
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../styles/detail-produk.css">
</head>

<body class="font-sans bg-surface-50 min-h-screen">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5QG7XXWW"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    
    <div class="max-w-md mx-auto bg-white min-h-screen shadow-xl relative pb-20">
        
        <!-- Header -->
        <header class="glass sticky top-0 z-50 safe-top">
            <div class="px-3 py-2">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-2">
                        <button onclick="goBack()" class="w-8 h-8 bg-surface-100 hover:bg-surface-200 rounded-lg flex items-center justify-center transition-all active:scale-95">
                            <i data-lucide="arrow-left" class="w-4 h-4 text-surface-700"></i>
                        </button>
                        <div class="flex-1">
                            <input type="text" placeholder="Cari produk..." class="w-full px-3 py-1.5 bg-surface-100 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-primary-500">
                        </div>
                    </div>
                    <div class="flex items-center space-x-1 ml-2">
                        <button class="w-8 h-8 bg-surface-100 hover:bg-surface-200 rounded-lg flex items-center justify-center transition-all active:scale-95">
                            <i data-lucide="shopping-cart" class="w-4 h-4 text-surface-700"></i>
                        </button>
                        <button class="w-8 h-8 bg-surface-100 hover:bg-surface-200 rounded-lg flex items-center justify-center transition-all active:scale-95">
                            <i data-lucide="share" class="w-4 h-4 text-surface-700"></i>
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Product Images -->
        <div class="relative">
            <div class="swiper product-swiper">
                <div class="swiper-wrapper">
                    <?php foreach($product_images as $index => $image): ?>
                    <div class="swiper-slide">
                        <div class="aspect-square bg-surface-100">
                            <img src="<?= $image ?>" alt="<?= $product['nama'] ?> - Image <?= $index + 1 ?>" class="w-full h-full object-cover">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            
            <!-- Wishlist Button -->
            <button class="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-all active:scale-95">
                <i data-lucide="heart" class="w-4 h-4 text-surface-600"></i>
            </button>
            
            <!-- Image Counter -->
            <div class="absolute bottom-3 right-3 bg-black/50 text-white px-2 py-0.5 rounded-full text-xs font-medium">
                <span id="current-slide">1</span>/<span><?= count($product_images) ?></span>
            </div>
        </div>

        <!-- Product Info -->
        <div class="px-3 py-4 space-y-4">
            <!-- Price Section -->
            <div class="space-y-2">
                <div class="flex items-center space-x-2">
                    <div class="text-lg font-bold text-surface-900">
                        <?= $helper->formatPrice($price_data['harga'] ?? 0) ?>
                    </div>
                    <?php if(isset($price_data['harga_asli']) && $price_data['harga_asli'] > $price_data['harga']): ?>
                    <div class="flex items-center space-x-1">
                        <div class="text-xs text-surface-500 line-through">
                            <?= $helper->formatPrice($price_data['harga_asli']) ?>
                        </div>
                        <div class="bg-red-100 text-red-600 px-1.5 py-0.5 rounded text-xs font-semibold">
                            <?= round((($price_data['harga_asli'] - $price_data['harga']) / $price_data['harga_asli']) * 100) ?>%
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Installment Info -->
                <div class="flex items-center space-x-1 text-xs">
                    <i data-lucide="credit-card" class="w-3 h-3 text-primary-600"></i>
                    <span class="text-primary-600 font-medium">Cicilan 0%</span>
                    <span class="text-surface-600">Mulai dari <?= $installment['formatted_monthly'] ?>/bulan</span>
                </div>
            </div>

            <!-- Product Title & Rating -->
            <div class="space-y-2">
                <h1 class="text-base font-bold text-surface-900 line-clamp-2"><?= $product['nama'] ?></h1>
                
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-1">
                        <div class="flex items-center space-x-1">
                            <i data-lucide="star" class="w-3 h-3 text-yellow-400 fill-current"></i>
                            <span class="text-xs font-medium text-surface-900"><?= $product['rating'] ?? '-' ?></span>
                        </div>
                        <span class="text-xs text-surface-500">•</span>
                        <span class="text-xs text-surface-500"><?= $product['terjual'] ?? '-' ?> terjual</span>
                    </div>
                    
                    <!-- Cabang Selector -->
                    <?php CabangSelector::renderButton($selected_cabang, $cabang_data); ?>
                </div>
            </div>

            <!-- Store Info -->
            <div class="bg-surface-50 rounded-lg p-3 space-y-2">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="store" class="w-4 h-4 text-primary-600"></i>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-sm font-semibold text-surface-900"><?= $cabang_data['nama'] ?></h3>
                        <p class="text-xs text-surface-600 line-clamp-1"><?= $cabang_data['alamat'] ?></p>
                    </div>
                    <button class="text-primary-600 text-xs font-medium">Lihat</button>
                </div>
                
                <div class="flex items-center justify-between text-xs">
                    <div class="flex items-center space-x-3">
                            <div class="flex items-center space-x-1">
                                <i data-lucide="star" class="w-3 h-3 text-yellow-400 fill-current"></i>
                                <span class="text-surface-900"><?= $cabang_data['rating'] ?? '-' ?></span>
                            </div>
                            <div class="flex items-center space-x-1">
                                <i data-lucide="users" class="w-3 h-3 text-surface-500"></i>
                                <span class="text-surface-600"><?= $cabang_data['followers'] ?? '-' ?></span>
                            </div>
                        </div>
                    <div class="flex items-center space-x-1">
                        <i data-lucide="clock" class="w-3 h-3 text-surface-500"></i>
                        <span class="text-surface-600"><?= $cabang_data['jam_operasional'] ?></span>
                    </div>
                </div>
            </div>

            <!-- Shipping Info -->
            <div class="bg-green-50 border border-green-200 rounded-lg p-3">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 bg-green-100 rounded-lg flex items-center justify-center">
                        <i data-lucide="truck" class="w-3 h-3 text-green-600"></i>
                    </div>
                    <div class="flex-1">
                        <div class="flex items-center space-x-1">
                            <span class="text-green-600 text-xs font-semibold">Gratis Ongkir</span>
                            <span class="bg-green-100 text-green-700 px-1 py-0.5 rounded text-xs font-medium"><?= $shipping['estimated_delivery'] ?></span>
                        </div>
                        <p class="text-xs text-green-700"><?= $shipping['courier'] ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="px-3">
            <div class="flex space-x-4 border-b border-surface-200">
                <button class="tab-button tab-active py-2 text-xs font-medium transition-all" data-tab="description">Deskripsi</button>
                <button class="tab-button py-2 text-xs font-medium text-surface-500 transition-all" data-tab="specifications">Spesifikasi</button>
                <button class="tab-button py-2 text-xs font-medium text-surface-500 transition-all" data-tab="reviews">Ulasan</button>
            </div>
        </div>

        <!-- Tab Content -->
        <div class="px-3 py-4">
            <!-- Description Tab -->
            <div id="description" class="tab-content">
                <div class="space-y-3">
                    <div class="space-y-3">
                        <?php if (!empty($product['deskripsi'])): ?>
                            <div class="product-description">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">Deskripsi Produk</h2>
                                <p class="text-sm text-surface-600"><?= htmlspecialchars(is_array($product['deskripsi']) ? implode('<br>', $product['deskripsi']) : $product['deskripsi']) ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($product['fitur']) && is_array($product['fitur'])): ?>
                            <div class="product-features">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">Fitur Unggulan</h2>
                                <ul class="list-disc list-inside text-sm text-surface-600 space-y-1">
                                    <?php foreach ($product['fitur'] as $feature): ?>
                                        <li><?= htmlspecialchars($feature) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($product['manfaat']) && is_array($product['manfaat'])): ?>
                            <div class="product-benefits">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">Manfaat</h2>
                                <ul class="list-disc list-inside text-sm text-surface-600 space-y-1">
                                    <?php foreach ($product['manfaat'] as $benefit): ?>
                                        <li><?= htmlspecialchars($benefit) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($product['cara_penggunaan'])): ?>
                            <div class="product-how-to-use">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">Cara Penggunaan</h2>
                                <p class="text-sm text-surface-600"><?= htmlspecialchars(is_array($product['cara_penggunaan']) ? implode('<br>', $product['cara_penggunaan']) : $product['cara_penggunaan']) ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($product['faq']) && is_array($product['faq'])): ?>
                            <div class="product-faq">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">FAQ</h2>
                                <div class="space-y-2">
                                    <?php foreach ($product['faq'] as $qa): ?>
                                        <div class="faq-item bg-surface-50 p-3 rounded-lg">
                                            <h3 class="text-sm font-medium text-surface-900 mb-1"><?= htmlspecialchars($qa['question']) ?></h3>
                                            <p class="text-xs text-surface-600"><?= htmlspecialchars($qa['answer']) ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($product['videos']) && is_array($product['videos'])): ?>
                            <div class="product-videos">
                                <h2 class="text-sm font-semibold text-surface-900 mb-2">Video Terkait</h2>
                                <div class="grid grid-cols-1 gap-3">
                                    <?php foreach ($product['videos'] as $video): ?>
                                        <div class="video-item aspect-video bg-black rounded-lg overflow-hidden">
                                            <iframe src="https://www.youtube.com/embed/<?= htmlspecialchars($video['id']) ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-full h-full"></iframe>
                                        </div>
                                        <p class="text-xs text-surface-600 mt-1"><?= htmlspecialchars($video['title']) ?></p>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            

            <!-- Reviews Tab -->
            <div id="reviews" class="tab-content hidden">
                <div class="space-y-3">
                    <p class="text-sm text-surface-500 text-center py-6">Ulasan produk akan segera hadir</p>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <?php if(!empty($related_products)): ?>
        <div class="px-3 py-4 border-t border-surface-200">
            <h3 class="text-sm font-bold text-surface-900 mb-3">Produk Terkait</h3>
            <div class="grid grid-cols-2 gap-3">
                <?php foreach($related_products as $related): ?>
                <div class="bg-surface-50 rounded-lg p-2 space-y-1">
                    <div class="aspect-square bg-surface-100 rounded-lg overflow-hidden">
                        <img src="<?= htmlspecialchars($related['gambar'][0] ?? '/placeholder.jpg') ?>" alt="<?= htmlspecialchars($related['nama']) ?>" class="w-full h-full object-cover">
                    </div>
                    <h4 class="text-xs font-medium text-surface-900 line-clamp-2"><?= htmlspecialchars($related['nama']) ?></h4>
                    <div class="text-xs font-bold text-surface-900"><?= $helper->formatPrice($related['harga'] ?? 0) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Bottom Action Bar -->
    <div class="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-surface-200 safe-bottom">
        <div class="px-3 py-2">
            <div class="flex items-center space-x-2">
                <button class="flex-1 bg-surface-100 hover:bg-surface-200 text-surface-700 py-2 px-3 rounded-lg text-xs font-medium transition-all">
                    <i data-lucide="message-circle" class="w-4 h-4 inline mr-1"></i>
                    Chat
                </button>
                <button class="flex-1 bg-primary-600 hover:bg-primary-700 text-white py-2 px-3 rounded-lg text-xs font-medium transition-all">
                    <i data-lucide="shopping-cart" class="w-4 h-4 inline mr-1"></i>
                    Beli Sekarang
                </button>
            </div>
        </div>
    </div>

    <!-- Cabang Selector Modal -->
    <?php CabangSelector::renderModal($selected_cabang); ?>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    
    <script>
        // Initialize Swiper
        const swiper = new Swiper('.product-swiper', {
            pagination: { el: '.swiper-pagination', clickable: true },
            on: {
                slideChange: function() {
                    document.getElementById('current-slide').textContent = this.activeIndex + 1;
                }
            }
        });

        // Tab switching
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.dataset.tab;
                
                // Update button states
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('tab-active');
                    btn.classList.add('text-surface-500');
                });
                button.classList.add('tab-active');
                button.classList.remove('text-surface-500');
                
                // Update content
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.add('hidden');
                });
                document.getElementById(tabName).classList.remove('hidden');
            });
        });

        // Initialize Lucide icons
        lucide.createIcons();

        // Go back function
        function goBack() {
            window.history.back();
        }
    </script>

    <!-- Cabang Selector Script -->
    <?php CabangSelector::renderScript(); ?>
</body>
</html>
