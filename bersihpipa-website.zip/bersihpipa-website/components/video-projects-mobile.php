<?php
// Mobile Video Projects Component
$video_json_path = __DIR__ . '/../data/video/youtube.json';
$videos = [];
if (file_exists($video_json_path)) {
    $video_json = file_get_contents($video_json_path);
    $videos = json_decode($video_json, true);
}
$total_videos = count($videos);
$first_video = $total_videos > 0 ? $videos[0] : null;
?>
<div class="bg-white rounded-2xl shadow-modern border border-surface-100 overflow-hidden slide-in" data-section="video-proyek" id="video-proyek">
    <div class="p-4">
        <h3 class="text-sm font-semibold text-surface-900 mb-4 flex items-center">
            <i data-lucide="video" class="w-4 h-4 mr-2 text-red-500"></i>
            Video Proyek Kami
        </h3>
        
        <!-- Video Player -->
        <div class="relative aspect-video rounded-xl overflow-hidden mb-4 bg-black">
            <div id="video-thumbnail-mobile" 
                 class="relative w-full h-full bg-cover bg-center cursor-pointer group" 
                 onclick="playCurrentVideoMobile()"
                 style="background-image: url('https://img.youtube.com/vi/<?= $first_video ? htmlspecialchars($first_video['id']) : '' ?>/maxresdefault.jpg')">
                <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center group-hover:bg-opacity-30 transition-all duration-300">
                    <div class="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                        <i data-lucide="play" class="h-8 w-8 text-white ml-1"></i>
                    </div>
                </div>
                <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                    <h4 id="video-title-mobile" class="text-white font-bold text-sm mb-1"><?= $first_video ? htmlspecialchars($first_video['title']) : 'Video tidak tersedia' ?></h4>
                    <div class="flex items-center justify-between text-xs text-gray-300">
                        <span id="video-duration-mobile"><?= $first_video ? htmlspecialchars($first_video['duration']) : '0:00' ?></span>
                        <span id="video-views-mobile"><?= $first_video ? htmlspecialchars($first_video['views']) : '0' ?> views</span>
                    </div>
                </div>
            </div>
            <iframe id="video-iframe-mobile" 
                    class="w-full h-full hidden" 
                    allowfullscreen 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
            </iframe>
        </div>

        <!-- Video Navigation -->
        <div class="flex items-center justify-between mb-4">
            <button onclick="previousVideoMobile()" 
                    class="flex items-center bg-surface-100 hover:bg-surface-200 px-3 py-2 rounded-lg transition-all duration-300 active:scale-95">
                <i data-lucide="chevron-left" class="h-4 w-4 mr-1"></i> 
                <span class="text-xs font-medium">Prev</span>
            </button>
            <div class="text-center bg-surface-50 px-3 py-2 rounded-lg">
                <span class="text-xs font-semibold text-surface-700">
                    <span id="current-video-index-mobile">1</span> / <span id="total-videos-mobile"><?= $total_videos ?></span>
                </span>
            </div>
            <button onclick="nextVideoMobile()" 
                    class="flex items-center bg-surface-100 hover:bg-surface-200 px-3 py-2 rounded-lg transition-all duration-300 active:scale-95">
                <span class="text-xs font-medium">Next</span>
                <i data-lucide="chevron-right" class="h-4 w-4 ml-1"></i>
            </button>
        </div>

        <!-- Action Buttons -->
        <div class="space-y-3">
            <button onclick="window.open('https://www.youtube.com/@fluksaqua?sub_confirmation=1', '_blank')" 
                    class="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg flex items-center justify-center transition-all duration-300 shadow-lg hover:shadow-xl active:scale-95 font-semibold">
                <i data-lucide="external-link" class="h-4 w-4 mr-2"></i>
                Subscribe Channel FLUKS Aqua
            </button>
            <button onclick="videoConsultationWhatsAppMobile()" 
                    class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl active:scale-95 font-semibold">
                <i data-lucide="message-circle" class="h-4 w-4 mr-2 inline"></i>
                Konsultasi Gratis via WhatsApp
            </button>
        </div>
    </div>
</div>

<script>
// Mobile Video Management
class MobileVideoManager {
    constructor(videos) {
        this.currentVideoIndex = 0;
        this.videos = videos;
        this.updateUI();
    }

    updateUI() {
        if (this.videos.length === 0) return;
        const currentVideo = this.videos[this.currentVideoIndex];
        
        // Update thumbnail
        const thumbnail = document.getElementById('video-thumbnail-mobile');
        if (thumbnail) {
            thumbnail.style.backgroundImage = `url(https://img.youtube.com/vi/${currentVideo.id}/maxresdefault.jpg)`;
        }

        // Update video info
        const elements = {
            'video-title-mobile': currentVideo.title,
            'video-duration-mobile': currentVideo.duration,
            'video-views-mobile': `${currentVideo.views} views`
        };

        Object.entries(elements).forEach(([id, content]) => {
            const element = document.getElementById(id);
            if (element) element.textContent = content;
        });

        // Update navigation
        const currentIndex = document.getElementById('current-video-index-mobile');
        const totalVideos = document.getElementById('total-videos-mobile');
        if (currentIndex) currentIndex.textContent = this.currentVideoIndex + 1;
        if (totalVideos) totalVideos.textContent = this.videos.length;

        // Reset video player
        const iframe = document.getElementById('video-iframe-mobile');
        const thumbnailDiv = document.getElementById('video-thumbnail-mobile');
        if (iframe && thumbnailDiv) {
            iframe.src = ''; // Clear src to stop video
            iframe.classList.add('hidden');
            thumbnailDiv.classList.remove('hidden');
        }
    }

    nextVideo() {
        if (this.videos.length === 0) return;
        this.currentVideoIndex = (this.currentVideoIndex + 1) % this.videos.length;
        this.updateUI();
    }

    previousVideo() {
        if (this.videos.length === 0) return;
        this.currentVideoIndex = (this.currentVideoIndex - 1 + this.videos.length) % this.videos.length;
        this.updateUI();
    }

    playCurrentVideo() {
        if (this.videos.length === 0) return;
        const currentVideo = this.videos[this.currentVideoIndex];
        
        if (currentVideo) {
            const iframe = document.getElementById('video-iframe-mobile');
            const thumbnail = document.getElementById('video-thumbnail-mobile');
            
            if (iframe && thumbnail) {
                iframe.src = `https://www.youtube.com/embed/${currentVideo.id}?autoplay=1&rel=0&modestbranding=1`;
                iframe.classList.remove('hidden');
                thumbnail.classList.add('hidden');
            }
        }
    }
}

// Initialize mobile video manager with data from PHP
const videosData = <?= json_encode($videos, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?>;
const mobileVideoManager = new MobileVideoManager(videosData);

// Global functions
function nextVideoMobile() {
    mobileVideoManager.nextVideo();
}

function previousVideoMobile() {
    mobileVideoManager.previousVideo();
}

function playCurrentVideoMobile() {
    mobileVideoManager.playCurrentVideo();
}

function videoConsultationWhatsAppMobile() {
    const currentUrl = window.location.href;
    const message = `Halo FLUKS Water Treatment, saya tertarik dengan layanan detox pipa setelah melihat video proyek Anda.\n\nDari: ${currentUrl}`;
    const whatsappUrl = `https://wa.me/6281236937200?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Make functions globally available
window.nextVideoMobile = nextVideoMobile;
window.previousVideoMobile = previousVideoMobile;
window.playCurrentVideoMobile = playCurrentVideoMobile;
window.videoConsultationWhatsAppMobile = videoConsultationWhatsAppMobile;
</script>