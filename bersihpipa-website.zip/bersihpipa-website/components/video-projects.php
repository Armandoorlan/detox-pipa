<?php
// Video Projects Component with improved YouTube API integration
?>
<section class="py-20 bg-white" data-section="video-proyek" id="video-proyek">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Video Proyek Kami</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                Lihat hasil kerja nyata dari proyek-proyek yang telah kami kerjakan
            </p>
        </div>

        <div class="max-w-7xl mx-auto">
            <!-- Tab Navigation -->
            <div class="flex justify-center mb-8">
                <div class="bg-gray-100 rounded-2xl p-2 shadow-inner">
                    <button onclick="switchVideoTab('videos')" 
                            id="videos-tab" 
                            class="px-8 py-3 rounded-xl font-semibold transition-all duration-300 bg-white text-blue-600 shadow-lg">
                        Videos (<span id="videos-count">0</span>)
                    </button>
                    <button onclick="switchVideoTab('shorts')" 
                            id="shorts-tab" 
                            class="px-8 py-3 rounded-xl font-semibold transition-all duration-300 text-gray-600 hover:text-blue-600 hover:bg-blue-50">
                        Shorts (<span id="shorts-count">0</span>)
                    </button>
                </div>
            </div>

            <!-- Video Container -->
            <div id="video-container">
                <!-- Loading State -->
                <div id="video-loading" class="flex justify-center items-center py-20">
                    <div class="text-center">
                        <div class="animate-spin h-16 w-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-6"></div>
                        <p class="text-gray-600 text-lg">Memuat konten dari channel @fluksaqua...</p>
                    </div>
                </div>

                <!-- Video Content -->
                <div id="video-content" class="hidden">
                    <!-- Main Video Player -->
                    <div class="relative aspect-video rounded-2xl overflow-hidden mb-8 bg-black shadow-2xl">
                        <div id="video-thumbnail" 
                             class="relative w-full h-full bg-cover bg-center cursor-pointer group" 
                             onclick="playCurrentVideo()">
                            <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center group-hover:bg-opacity-30 transition-all duration-300">
                                <div class="w-24 h-24 bg-red-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                                    <i data-lucide="play" class="h-10 w-10 text-white ml-1"></i>
                                </div>
                            </div>
                            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
                                <div class="flex items-center justify-between mb-3">
                                    <div class="flex items-center space-x-3">
                                        <span id="video-type-badge" class="px-3 py-1 rounded-full text-sm font-semibold bg-blue-600 text-white">VIDEO</span>
                                        <span id="video-duration" class="text-sm text-gray-300 bg-black/50 px-2 py-1 rounded">0:00</span>
                                    </div>
                                    <span id="video-views" class="text-sm text-gray-300 bg-black/50 px-2 py-1 rounded"></span>
                                </div>
                                <h3 id="video-title" class="text-2xl lg:text-3xl font-bold text-white line-clamp-2 mb-2">Loading...</h3>
                                <p id="video-date" class="text-gray-300">Loading...</p>
                            </div>
                        </div>
                        <iframe id="video-iframe" 
                                class="w-full h-full hidden" 
                                allowfullscreen 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                        </iframe>
                    </div>

                    <!-- Navigation Controls -->
                    <div class="flex items-center justify-between mb-8">
                        <button onclick="previousVideo()" 
                                class="flex items-center bg-white border-2 border-gray-300 hover:border-blue-500 px-6 py-3 rounded-xl hover:bg-blue-50 transition-all duration-300 shadow-lg hover:shadow-xl">
                            <i data-lucide="chevron-left" class="h-5 w-5 mr-2"></i> 
                            Previous
                        </button>
                        <div class="text-center bg-gray-100 px-6 py-3 rounded-xl">
                            <span class="font-semibold text-gray-700">
                                <span id="current-video-index">1</span> of <span id="total-videos">1</span>
                            </span>
                        </div>
                        <button onclick="nextVideo()" 
                                class="flex items-center bg-white border-2 border-gray-300 hover:border-blue-500 px-6 py-3 rounded-xl hover:bg-blue-50 transition-all duration-300 shadow-lg hover:shadow-xl">
                            Next 
                            <i data-lucide="chevron-right" class="h-5 w-5 ml-2"></i>
                        </button>
                    </div>

                    <!-- Video Grid -->
                    <div id="video-list" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"></div>

                    <!-- Action Buttons -->
                    <div class="text-center space-y-6">
                        <div class="flex flex-col sm:flex-row gap-6 justify-center">
                            <button onclick="window.open('https://www.youtube.com/@fluksaqua?sub_confirmation=1', '_blank')" 
                                    class="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-xl flex items-center gap-3 justify-center transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold">
                                <i data-lucide="external-link" class="h-5 w-5"></i>
                                Subscribe Channel FLUKS Aqua
                            </button>
                            <button onclick="videoConsultationWhatsApp()" 
                                    class="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold">
                                Konsultasi Gratis via WhatsApp
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// YouTube Video Management System
class YouTubeVideoManager {
    constructor() {
        this.API_KEY = 'AIzaSyBb6ZQ5Ycrh4wiUB54nykffuM6iKZ1uHho';
        this.CHANNEL_HANDLE = '@fluksaqua';
        this.FALLBACK_CHANNEL_ID = 'UCnXnSGFNUJ3iVuP3sMeKGTA';
        this.currentVideoIndex = 0;
        this.currentVideoTab = 'videos';
        this.videosData = [];
        this.shortsData = [];
    }

    async loadVideos() {
        try {
            this.showLoading();
            
            // Get channel ID
            const channelId = await this.getChannelId();
            
            // Fetch videos
            const videos = await this.fetchChannelVideos(channelId);
            
            // Get detailed video information
            const videoDetails = await this.getVideoDetails(videos);
            
            // Process and categorize videos
            this.processVideos(videoDetails);
            
            // Update UI
            this.updateVideoUI();
            
        } catch (error) {
            console.error('Error loading videos:', error);
            this.loadDemoVideos();
        } finally {
            this.hideLoading();
        }
    }

    async getChannelId() {
        try {
            const response = await fetch(
                `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(this.CHANNEL_HANDLE)}&type=channel&key=${this.API_KEY}&maxResults=1`
            );
            
            if (!response.ok) throw new Error(`Channel search failed: ${response.status}`);
            
            const data = await response.json();
            
            if (data.items && data.items.length > 0) {
                return data.items[0].snippet.channelId || data.items[0].id?.channelId || this.FALLBACK_CHANNEL_ID;
            }
            
            return this.FALLBACK_CHANNEL_ID;
        } catch (error) {
            console.warn('Using fallback channel ID:', error);
            return this.FALLBACK_CHANNEL_ID;
        }
    }

    async fetchChannelVideos(channelId) {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&maxResults=50&order=date&type=video&key=${this.API_KEY}`
        );
        
        if (!response.ok) throw new Error(`Videos search failed: ${response.status}`);
        
        const data = await response.json();
        
        if (!data.items || data.items.length === 0) {
            throw new Error('No videos found in channel');
        }
        
        return data.items;
    }

    async getVideoDetails(videos) {
        const videoIds = videos.map(item => item.id.videoId).join(',');
        
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/videos?part=contentDetails,snippet,statistics&id=${videoIds}&key=${this.API_KEY}`
        );
        
        if (!response.ok) throw new Error(`Video details failed: ${response.status}`);
        
        const data = await response.json();
        
        if (!data.items || data.items.length === 0) {
            throw new Error('No video details found');
        }
        
        return data.items;
    }

    processVideos(videos) {
        this.videosData = [];
        this.shortsData = [];

        videos.forEach(video => {
            const duration = video.contentDetails.duration;
            const durationInSeconds = this.parseDuration(duration);
            const isShort = durationInSeconds <= 60 && durationInSeconds > 0;

            const videoData = {
                id: video.id,
                title: video.snippet.title,
                thumbnail: video.snippet.thumbnails?.high?.url || video.snippet.thumbnails?.medium?.url || '/placeholder.svg?height=400&width=600',
                publishedAt: new Date(video.snippet.publishedAt).toLocaleDateString('id-ID', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }),
                description: video.snippet.description || 'Video dari FLUKS Water Treatment',
                type: isShort ? 'short' : 'video',
                duration: this.formatDuration(duration),
                viewCount: this.formatViewCount(video.statistics?.viewCount)
            };

            if (isShort) {
                this.shortsData.push(videoData);
            } else {
                this.videosData.push(videoData);
            }
        });
    }

    parseDuration(duration) {
        if (!duration) return 0;
        const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
        if (!match) return 0;
        const hours = parseInt(match[1] || '0');
        const minutes = parseInt(match[2] || '0');
        const seconds = parseInt(match[3] || '0');
        return hours * 3600 + minutes * 60 + seconds;
    }

    formatDuration(duration) {
        const totalSeconds = this.parseDuration(duration);
        if (totalSeconds === 0) return '0:00';
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        if (hours > 0) {
            return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    formatViewCount(viewCount) {
        if (!viewCount) return '0 views';
        const count = parseInt(viewCount);
        if (count >= 1000000) {
            return `${(count / 1000000).toFixed(1)}M views`;
        } else if (count >= 1000) {
            return `${(count / 1000).toFixed(1)}K views`;
        }
        return `${count} views`;
    }

    loadDemoVideos() {
        // Fallback demo videos
        this.videosData = [
            {
                id: 's22mhUZJIp0',
                title: 'Filter Air Mangandung Mangan Fluks Water Filter & Treatment',
                thumbnail: 'https://img.youtube.com/vi/s22mhUZJIp0/maxresdefault.jpg',
                publishedAt: '3 bulan yang lalu',
                description: 'Solusi filter air untuk mengatasi kandungan mangan dalam air.',
                type: 'video',
                duration: '8:45',
                viewCount: '1.2K views'
            },
            {
                id: 'b2OVSGbMvKM',
                title: 'Pengerjaan Filter Air Mengandung Mangan',
                thumbnail: 'https://img.youtube.com/vi/b2OVSGbMvKM/maxresdefault.jpg',
                publishedAt: '3 bulan yang lalu',
                description: 'Tutorial pengerjaan instalasi filter air untuk mengatasi masalah mangan.',
                type: 'video',
                duration: '12:30',
                viewCount: '856 views'
            }
        ];

        this.shortsData = [
            {
                id: 'iYr3K5eV04A',
                title: 'Tips Filter Air Cepat #flukswater #shorts',
                thumbnail: 'https://img.youtube.com/vi/iYr3K5eV04A/maxresdefault.jpg',
                publishedAt: '2 minggu yang lalu',
                description: 'Tips cepat untuk filter air berkualitas.',
                type: 'short',
                duration: '0:45',
                viewCount: '2.3K views'
            }
        ];
    }

    switchTab(tab) {
        this.currentVideoTab = tab;
        this.currentVideoIndex = 0;
        
        // Update tab buttons
        document.getElementById('videos-tab').className = tab === 'videos' 
            ? 'px-8 py-3 rounded-xl font-semibold transition-all duration-300 bg-white text-blue-600 shadow-lg'
            : 'px-8 py-3 rounded-xl font-semibold transition-all duration-300 text-gray-600 hover:text-blue-600 hover:bg-blue-50';
        
        document.getElementById('shorts-tab').className = tab === 'shorts'
            ? 'px-8 py-3 rounded-xl font-semibold transition-all duration-300 bg-white text-blue-600 shadow-lg'
            : 'px-8 py-3 rounded-xl font-semibold transition-all duration-300 text-gray-600 hover:text-blue-600 hover:bg-blue-50';

        this.updateVideoUI();
    }

    updateVideoUI() {
        const currentContent = this.currentVideoTab === 'videos' ? this.videosData : this.shortsData;
        const currentVideo = currentContent[this.currentVideoIndex] || currentContent[0];

        if (!currentVideo) return;

        // Update counts
        document.getElementById('videos-count').textContent = this.videosData.length;
        document.getElementById('shorts-count').textContent = this.shortsData.length;

        // Update main video display
        const thumbnail = document.getElementById('video-thumbnail');
        if (thumbnail) {
            thumbnail.style.backgroundImage = `url(${currentVideo.thumbnail})`;
        }

        const elements = {
            'video-title': currentVideo.title,
            'video-date': currentVideo.publishedAt,
            'video-duration': currentVideo.duration,
            'video-views': currentVideo.viewCount || ''
        };

        Object.entries(elements).forEach(([id, content]) => {
            const element = document.getElementById(id);
            if (element) element.textContent = content;
        });

        // Update type badge
        const typeBadge = document.getElementById('video-type-badge');
        if (typeBadge) {
            typeBadge.textContent = currentVideo.type === 'short' ? 'SHORT' : 'VIDEO';
            typeBadge.className = currentVideo.type === 'short' 
                ? 'px-3 py-1 rounded-full text-sm font-semibold bg-red-600 text-white'
                : 'px-3 py-1 rounded-full text-sm font-semibold bg-blue-600 text-white';
        }

        // Update navigation
        const currentIndex = document.getElementById('current-video-index');
        const totalVideos = document.getElementById('total-videos');
        if (currentIndex) currentIndex.textContent = this.currentVideoIndex + 1;
        if (totalVideos) totalVideos.textContent = currentContent.length;

        // Update video grid
        this.updateVideoGrid();

        // Reset video player
        const iframe = document.getElementById('video-iframe');
        const thumbnailDiv = document.getElementById('video-thumbnail');
        if (iframe && thumbnailDiv) {
            iframe.classList.add('hidden');
            thumbnailDiv.classList.remove('hidden');
        }
    }

    updateVideoGrid() {
        const currentContent = this.currentVideoTab === 'videos' ? this.videosData : this.shortsData;
        const grid = document.getElementById('video-list');
        
        if (!grid) return;
        
        grid.innerHTML = '';

        currentContent.slice(0, 12).forEach((video, index) => {
            const videoElement = document.createElement('div');
            videoElement.className = `relative aspect-video rounded-xl overflow-hidden cursor-pointer transition-all duration-300 ${
                index === this.currentVideoIndex ? 'ring-4 ring-blue-500 shadow-2xl' : 'hover:shadow-xl hover:scale-105'
            }`;
            videoElement.onclick = () => this.selectVideo(index);

            videoElement.innerHTML = `
                <div class="w-full h-full bg-cover bg-center" style="background-image: url(${video.thumbnail})"></div>
                <div class="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center group-hover:bg-opacity-10 transition-all">
                    <i data-lucide="play" class="h-8 w-8 text-white opacity-80"></i>
                </div>
                <div class="absolute top-3 left-3">
                    <span class="px-2 py-1 rounded-lg text-xs font-semibold ${
                        video.type === 'short' ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'
                    }">
                        ${video.type === 'short' ? 'SHORT' : 'VIDEO'}
                    </span>
                </div>
                <div class="absolute bottom-3 right-3 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    ${video.duration}
                </div>
                <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-3">
                    <p class="text-white text-sm font-semibold line-clamp-2">${video.title}</p>
                    ${video.viewCount ? `<p class="text-gray-300 text-xs mt-1">${video.viewCount}</p>` : ''}
                </div>
            `;

            grid.appendChild(videoElement);
        });

        lucide.createIcons();
    }

    selectVideo(index) {
        this.currentVideoIndex = index;
        this.updateVideoUI();
    }

    nextVideo() {
        const currentContent = this.currentVideoTab === 'videos' ? this.videosData : this.shortsData;
        this.currentVideoIndex = (this.currentVideoIndex + 1) % currentContent.length;
        this.updateVideoUI();
    }

    previousVideo() {
        const currentContent = this.currentVideoTab === 'videos' ? this.videosData : this.shortsData;
        this.currentVideoIndex = (this.currentVideoIndex - 1 + currentContent.length) % currentContent.length;
        this.updateVideoUI();
    }

    playCurrentVideo() {
        const currentContent = this.currentVideoTab === 'videos' ? this.videosData : this.shortsData;
        const currentVideo = currentContent[this.currentVideoIndex];
        
        if (currentVideo) {
            const iframe = document.getElementById('video-iframe');
            const thumbnail = document.getElementById('video-thumbnail');
            
            if (iframe && thumbnail) {
                iframe.src = `https://www.youtube.com/embed/${currentVideo.id}?autoplay=1&rel=0&modestbranding=1`;
                iframe.classList.remove('hidden');
                thumbnail.classList.add('hidden');
            }
        }
    }

    showLoading() {
        const loading = document.getElementById('video-loading');
        const content = document.getElementById('video-content');
        if (loading) loading.classList.remove('hidden');
        if (content) content.classList.add('hidden');
    }

    hideLoading() {
        const loading = document.getElementById('video-loading');
        const content = document.getElementById('video-content');
        if (loading) loading.classList.add('hidden');
        if (content) content.classList.remove('hidden');
    }
}

// Initialize video manager
const videoManager = new YouTubeVideoManager();

// Global functions for backward compatibility
function switchVideoTab(tab) {
    videoManager.switchTab(tab);
}

function selectVideo(index) {
    videoManager.selectVideo(index);
}

function nextVideo() {
    videoManager.nextVideo();
}

function previousVideo() {
    videoManager.previousVideo();
}

function playCurrentVideo() {
    videoManager.playCurrentVideo();
}

function videoConsultationWhatsApp() {
    const currentUrl = window.location.href;
    const message = `Halo FLUKS Water Treatment, saya tertarik dengan layanan detox pipa setelah melihat video proyek Anda.\n\nDari: ${currentUrl}`;
    const whatsappUrl = `https://wa.me/6281236937200?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    videoManager.loadVideos();
});

// Make functions globally available
window.switchVideoTab = switchVideoTab;
window.selectVideo = selectVideo;
window.nextVideo = nextVideo;
window.previousVideo = previousVideo;
window.playCurrentVideo = playCurrentVideo;
window.videoConsultationWhatsApp = videoConsultationWhatsApp;
</script>
