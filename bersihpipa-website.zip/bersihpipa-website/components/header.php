<header class="glass sticky top-0 z-50 safe-top">
    <div class="px-4 py-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <button onclick="goBack()" class="w-10 h-10 bg-surface-100 hover:bg-surface-200 rounded-xl flex items-center justify-center transition-all active:scale-95">
                    <i data-lucide="arrow-left" class="w-5 h-5 text-surface-700"></i>
                </button>
                <div class="flex-1">
                    <input type="text" 
                           placeholder="Kamu lagi cari apa?" 
                           class="w-full px-4 py-2 bg-surface-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                </div>
            </div>
            <div class="flex items-center space-x-2 ml-3">
                <button class="w-10 h-10 bg-surface-100 hover:bg-surface-200 rounded-xl flex items-center justify-center transition-all active:scale-95">
                    <i data-lucide="shopping-cart" class="w-5 h-5 text-surface-700"></i>
                </button>
                <button class="w-10 h-10 bg-surface-100 hover:bg-surface-200 rounded-xl flex items-center justify-center transition-all active:scale-95">
                    <i data-lucide="share" class="w-5 h-5 text-surface-700"></i>
                </button>
                <button class="w-10 h-10 bg-surface-100 hover:bg-surface-200 rounded-xl flex items-center justify-center transition-all active:scale-95">
                    <i data-lucide="more-horizontal" class="w-5 h-5 text-surface-700"></i>
                </button>
            </div>
        </div>
    </div>
</header>