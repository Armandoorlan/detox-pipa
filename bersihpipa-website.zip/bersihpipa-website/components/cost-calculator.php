<?php
// Cost Calculator Component
?>
<section class="py-20 bg-gradient-to-br from-blue-50 to-indigo-100" data-section="hitung-biaya" id="hitung-biaya">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto">
            <div class="bg-white rounded-3xl shadow-2xl overflow-hidden">
                <!-- Header -->
                <div class="text-center p-8 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                    <h2 class="text-3xl lg:text-4xl font-bold mb-4">Hitung Biaya Detox Pipa</h2>
                    <p class="text-blue-100 text-lg">Dapatkan estimasi biaya untuk kebutuhan detox pipa Anda</p>
                </div>

                <!-- Form -->
                <div class="p-8 space-y-8">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label for="lantai" class="block text-sm font-semibold text-gray-700">Jumlah Lantai</label>
                            <input type="number" 
                                   id="lantai" 
                                   placeholder="Contoh: 2" 
                                   min="1" 
                                   max="10"
                                   class="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300">
                        </div>
                        <div class="space-y-2">
                            <label for="kamarMandi" class="block text-sm font-semibold text-gray-700">Jumlah Kamar Mandi</label>
                            <input type="number" 
                                   id="kamarMandi" 
                                   placeholder="Contoh: 3" 
                                   min="1" 
                                   max="20"
                                   class="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label for="kran" class="block text-sm font-semibold text-gray-700">Jumlah Kran</label>
                            <input type="number" 
                                   id="kran" 
                                   placeholder="Contoh: 10" 
                                   min="1" 
                                   max="50"
                                   class="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300">
                        </div>
                        <div class="space-y-2">
                            <label for="lokasi" class="block text-sm font-semibold text-gray-700">Alamat Lengkap</label>
                            <div class="relative">
                                <input type="text" 
                                       id="lokasi" 
                                       placeholder="Masukkan alamat lengkap..." 
                                       class="w-full pl-12 pr-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300">
                                <i data-lucide="map-pin" class="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                            </div>
                            <p id="maps-loading" class="text-xs text-gray-500">Loading Google Maps...</p>
                        </div>
                    </div>

                    <!-- Calculate Button -->
                    <button onclick="calculateCost()" 
                            class="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-4 rounded-xl text-xl font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                        <i data-lucide="calculator" class="h-6 w-6 mr-3 inline"></i>
                        Hitung Biaya
                    </button>

                    <!-- Result -->
                    <div id="cost-result" class="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6 text-center space-y-4 hidden">
                        <div class="flex items-center justify-center mb-4">
                            <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                                <i data-lucide="check-circle" class="h-8 w-8 text-green-600"></i>
                            </div>
                        </div>
                        <h3 class="font-bold text-green-800 text-xl">Estimasi Biaya</h3>
                        <p id="estimated-cost" class="text-4xl font-bold text-green-600">Rp 0</p>
                        <p class="text-sm text-green-700">*Harga dapat berubah sesuai kondisi lapangan</p>
                        <button onclick="costWhatsAppContact()" 
                                class="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-xl transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105">
                            <i data-lucide="message-circle" class="h-5 w-5 mr-2 inline"></i>
                            Konsultasi via WhatsApp
                        </button>
                    </div>

                    <!-- Service Areas -->
                    <div class="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
                        <h4 class="font-bold text-blue-800 mb-4 text-lg">Area Layanan Utama:</h4>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm text-blue-700">
                            <?php 
                            $areas = ['Malang', 'Blitar', 'Pasuruan', 'Mojokerto', 'Tulungagung', 'Probolinggo'];
                            foreach($areas as $area): ?>
                            <div class="flex items-center">
                                <i data-lucide="map-pin" class="h-4 w-4 mr-2"></i>
                                <span><?= $area ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <p class="text-xs text-blue-600 mt-4 text-center">*Untuk area lain, silakan konsultasi terlebih dahulu</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
let estimatedCost = null;
let autocompleteInstance = null;
let isGoogleMapsLoaded = false;

// Load Google Maps
function loadGoogleMaps() {
    if (window.google) {
        initializeAutocomplete();
        return;
    }

    const script = document.createElement('script');
    script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyA-YVE0U9M-giKLXwQryz-lc9VAlv1g_Us&libraries=places&callback=initializeAutocomplete';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);
}

function initializeAutocomplete() {
    isGoogleMapsLoaded = true;
    
    // Hide loading message
    const loadingElement = document.getElementById('maps-loading');
    if (loadingElement) {
        loadingElement.style.display = 'none';
    }

    // Initialize autocomplete
    const lokasiInput = document.getElementById('lokasi');
    if (lokasiInput && !autocompleteInstance) {
        autocompleteInstance = new google.maps.places.Autocomplete(lokasiInput, {
            types: ['address'],
            componentRestrictions: { country: 'ID' },
            fields: ['formatted_address', 'geometry', 'address_components']
        });
    }
}

function calculateCost() {
    const lantai = document.getElementById('lantai').value;
    const kamarMandi = document.getElementById('kamarMandi').value;
    const kran = document.getElementById('kran').value;
    const lokasi = document.getElementById('lokasi').value;

    if (!lantai || !kamarMandi || !kran || !lokasi) {
        alert('Mohon lengkapi semua data yang diperlukan');
        return;
    }

    // Calculate cost: Number of faucets × Rp 150,000
    const totalKran = parseInt(kran);
    const baseCost = totalKran * 150000;
    const locationMultiplier = getLocationMultiplier(lokasi);
    estimatedCost = Math.round(baseCost * locationMultiplier);

    // Display result
    document.getElementById('estimated-cost').textContent = `Rp ${estimatedCost.toLocaleString('id-ID')}`;
    document.getElementById('cost-result').classList.remove('hidden');
    
    // Scroll to result
    document.getElementById('cost-result').scrollIntoView({ behavior: 'smooth' });
}

function getLocationMultiplier(address) {
    const lowerAddress = address.toLowerCase();
    
    // Location-based pricing multipliers
    if (lowerAddress.includes('jakarta')) return 1.3;
    if (lowerAddress.includes('surabaya')) return 1.2;
    if (lowerAddress.includes('bandung')) return 1.15;
    if (lowerAddress.includes('medan')) return 1.1;
    
    // Base areas (no multiplier)
    const baseAreas = ['malang', 'blitar', 'pasuruan', 'mojokerto', 'tulungagung', 'probolinggo'];
    if (baseAreas.some(area => lowerAddress.includes(area))) return 1.0;
    
    return 1.05; // Default slight increase for other areas
}

function costWhatsAppContact() {
    if (!estimatedCost) return;
    
    const formData = {
        lokasi: document.getElementById('lokasi').value,
        lantai: document.getElementById('lantai').value,
        kamarMandi: document.getElementById('kamarMandi').value,
        kran: document.getElementById('kran').value
    };

    const message = `🏠 *KONSULTASI DETOX PIPA - FLUKS WATER TREATMENT*

📍 *Lokasi:* ${formData.lokasi}
🏠 *Jumlah Lantai:* ${formData.lantai}
🚿 *Kamar Mandi:* ${formData.kamarMandi}
🚰 *Jumlah Kran:* ${formData.kran}
💰 *Estimasi Biaya:* Rp ${estimatedCost.toLocaleString('id-ID')}

📱 Dikirim dari: BersihPipa.com

Mohon info lebih lanjut untuk layanan detox pipa. Terima kasih! 🙏`;

    const whatsappUrl = `https://wa.me/6281236937200?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Initialize Google Maps when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadGoogleMaps();
});

// Make functions globally available
window.initializeAutocomplete = initializeAutocomplete;
window.calculateCost = calculateCost;
window.costWhatsAppContact = costWhatsAppContact;
</script>
