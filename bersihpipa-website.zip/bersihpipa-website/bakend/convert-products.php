<?php
/**
 * Convert Products Script
 * Mengkonversi file JSON produk terpisah menjadi format satu file per kategori
 */

class ProductConverter {
    private $produk_dir = '../data/produk/';
    private $kategori_layanan = [
        'filter-air' => 'katalog-filter.json',
        'plumbing' => 'katalog-plumbing.json',
        'pompa-air' => 'katalog-pompa-air.json',
        'water-heater' => 'katalog-water-heater.json',
        'pipa-mampet' => 'katalog-pipa-mampet.json',
        'perbaikan' => 'katalog-perbaikan.json'
    ];
    
    public function __construct() {
        if (!is_dir($this->produk_dir)) {
            mkdir($this->produk_dir, 0755, true);
        }
    }
    
    /**
     * Scan existing product files
     */
    public function scanExistingProducts() {
        $files = glob($this->produk_dir . '*.json');
        $products = [];
        
        foreach ($files as $file) {
            $filename = basename($file);
            
            // Skip if it's already a katalog file
            if (strpos($filename, 'katalog-') === 0) {
                continue;
            }
            
            $content = file_get_contents($file);
            $data = json_decode($content, true);
            
            if (json_last_error() === JSON_ERROR_NONE && $data) {
                $products[] = [
                    'file' => $filename,
                    'data' => $data
                ];
            }
        }
        
        return $products;
    }
    
    /**
     * Categorize products
     */
    public function categorizeProducts($products) {
        $categories = [];
        
        foreach ($products as $product) {
            $data = $product['data'];
            $kategori = $data['kategori'] ?? 'filter-air'; // Default to filter-air
            
            if (!isset($categories[$kategori])) {
                $categories[$kategori] = [];
            }
            
            $categories[$kategori][] = $product;
        }
        
        return $categories;
    }
    
    /**
     * Create katalog files
     */
    public function createKatalogFiles($categorized_products) {
        $results = [];
        
        foreach ($categorized_products as $kategori => $products) {
            if (!isset($this->kategori_layanan[$kategori])) {
                continue;
            }
            
            $filename = $this->kategori_layanan[$kategori];
            $filepath = $this->produk_dir . $filename;
            
            // Prepare katalog data
            $katalog_data = [
                'kategori' => $kategori,
                'nama_kategori' => $this->getKategoriName($kategori),
                'deskripsi' => 'Katalog produk ' . $this->getKategoriName($kategori),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'produk' => []
            ];
            
            // Add products
            foreach ($products as $product) {
                $product_data = $product['data'];
                
                // Ensure product has required fields
                if (!isset($product_data['id'])) {
                    $product_data['id'] = $this->generateProductId($kategori, $product_data['nama']);
                }
                
                if (!isset($product_data['created_at'])) {
                    $product_data['created_at'] = date('Y-m-d H:i:s');
                }
                
                $product_data['updated_at'] = date('Y-m-d H:i:s');
                
                $katalog_data['produk'][] = $product_data;
            }
            
            // Save katalog file
            $json_content = json_encode($katalog_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $success = file_put_contents($filepath, $json_content);
            
            $results[$kategori] = [
                'filename' => $filename,
                'success' => $success !== false,
                'product_count' => count($products),
                'file_size' => $success !== false ? strlen($json_content) : 0
            ];
        }
        
        return $results;
    }
    
    /**
     * Backup original files
     */
    public function backupOriginalFiles($products) {
        $backup_dir = $this->produk_dir . 'backup_' . date('Y-m-d_H-i-s') . '/';
        
        if (!is_dir($backup_dir)) {
            mkdir($backup_dir, 0755, true);
        }
        
        $backed_up = [];
        
        foreach ($products as $product) {
            $source = $this->produk_dir . $product['file'];
            $destination = $backup_dir . $product['file'];
            
            if (copy($source, $destination)) {
                $backed_up[] = $product['file'];
            }
        }
        
        return [
            'backup_dir' => $backup_dir,
            'backed_up' => $backed_up
        ];
    }
    
    /**
     * Remove original files (after backup)
     */
    public function removeOriginalFiles($products) {
        $removed = [];
        
        foreach ($products as $product) {
            $filepath = $this->produk_dir . $product['file'];
            
            if (file_exists($filepath) && unlink($filepath)) {
                $removed[] = $product['file'];
            }
        }
        
        return $removed;
    }
    
    /**
     * Generate product ID
     */
    private function generateProductId($kategori, $nama) {
        $prefix = strtoupper(str_replace('-', '', $kategori));
        $suffix = substr(preg_replace('/[^a-zA-Z0-9]/', '', $nama), 0, 3);
        return $prefix . '-' . $suffix . '-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
    }
    
    /**
     * Get kategori name
     */
    private function getKategoriName($kategori) {
        $names = [
            'filter-air' => 'Filter Air',
            'plumbing' => 'Plumbing',
            'pompa-air' => 'Pompa Air',
            'water-heater' => 'Water Heater',
            'pipa-mampet' => 'Pipa Mampet',
            'perbaikan' => 'Perbaikan'
        ];
        
        return $names[$kategori] ?? ucfirst(str_replace('-', ' ', $kategori));
    }
    
    /**
     * Get conversion summary
     */
    public function getConversionSummary() {
        $existing = $this->scanExistingProducts();
        $categorized = $this->categorizeProducts($existing);
        
        $summary = [
            'total_files' => count($existing),
            'categories' => []
        ];
        
        foreach ($categorized as $kategori => $products) {
            $summary['categories'][$kategori] = [
                'nama' => $this->getKategoriName($kategori),
                'product_count' => count($products),
                'files' => array_column($products, 'file')
            ];
        }
        
        return $summary;
    }
}

// Handle conversion request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $converter = new ProductConverter();
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'scan':
                $existing = $converter->scanExistingProducts();
                $summary = $converter->getConversionSummary();
                echo json_encode(['success' => true, 'data' => $summary]);
                break;
                
            case 'convert':
                $existing = $converter->scanExistingProducts();
                $categorized = $converter->categorizeProducts($existing);
                
                // Backup original files
                $backup = $converter->backupOriginalFiles($existing);
                
                // Create katalog files
                $results = $converter->createKatalogFiles($categorized);
                
                // Remove original files (optional)
                $remove_originals = $_POST['remove_originals'] ?? false;
                $removed = [];
                if ($remove_originals) {
                    $removed = $converter->removeOriginalFiles($existing);
                }
                
                echo json_encode([
                    'success' => true,
                    'data' => [
                        'backup' => $backup,
                        'katalog_files' => $results,
                        'removed_originals' => $removed
                    ]
                ]);
                break;
                
            default:
                echo json_encode(['success' => false, 'error' => 'Invalid action']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Convert Products - BersihPipa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto">
            <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h1 class="text-2xl font-bold text-gray-900">Convert Products to Katalog Format</h1>
                    <p class="text-gray-600 mt-2">Convert individual product JSON files to categorized katalog format</p>
                </div>
                
                <div class="p-6">
                    <!-- Scan Button -->
                    <div class="mb-6">
                        <button onclick="scanProducts()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            <i data-lucide="search" class="w-4 h-4 inline mr-2"></i>
                            Scan Existing Products
                        </button>
                    </div>
                    
                    <!-- Scan Results -->
                    <div id="scan-results" class="hidden mb-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Scan Results</h3>
                        <div id="scan-content" class="bg-gray-50 rounded-lg p-4"></div>
                    </div>
                    
                    <!-- Convert Options -->
                    <div id="convert-options" class="hidden mb-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Conversion Options</h3>
                        
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                            <div class="flex">
                                <i data-lucide="alert-triangle" class="w-5 h-5 text-yellow-600 mr-3 mt-0.5"></i>
                                <div>
                                    <h4 class="text-sm font-medium text-yellow-800">Important Notes</h4>
                                    <ul class="text-sm text-yellow-700 mt-2 space-y-1">
                                        <li>• Original files will be backed up before conversion</li>
                                        <li>• Products will be organized by category</li>
                                        <li>• Each category will have its own katalog JSON file</li>
                                        <li>• Product IDs will be preserved or generated if missing</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="flex items-center mb-4">
                            <input type="checkbox" id="remove-originals" class="mr-3">
                            <label for="remove-originals" class="text-sm text-gray-700">
                                Remove original files after successful conversion
                            </label>
                        </div>
                        
                        <button onclick="convertProducts()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors">
                            <i data-lucide="refresh-cw" class="w-4 h-4 inline mr-2"></i>
                            Convert Products
                        </button>
                    </div>
                    
                    <!-- Conversion Results -->
                    <div id="convert-results" class="hidden">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Conversion Results</h3>
                        <div id="convert-content" class="bg-gray-50 rounded-lg p-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let scanData = null;
        
        // Scan existing products
        async function scanProducts() {
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=scan'
                });
                
                const result = await response.json();
                if (result.success) {
                    scanData = result.data;
                    displayScanResults(result.data);
                    document.getElementById('convert-options').classList.remove('hidden');
                } else {
                    alert('Error scanning products: ' + result.error);
                }
            } catch (error) {
                console.error('Error scanning products:', error);
                alert('Error scanning products');
            }
        }
        
        // Display scan results
        function displayScanResults(data) {
            const content = document.getElementById('scan-content');
            
            let html = `
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-white rounded-lg p-4 border border-gray-200">
                        <h4 class="font-semibold text-gray-900 mb-2">Summary</h4>
                        <p class="text-sm text-gray-600">Total files found: <span class="font-medium">${data.total_files}</span></p>
                    </div>
                </div>
            `;
            
            if (Object.keys(data.categories).length > 0) {
                html += '<div class="mt-4"><h4 class="font-semibold text-gray-900 mb-3">Products by Category</h4>';
                
                Object.keys(data.categories).forEach(kategori => {
                    const category = data.categories[kategori];
                    html += `
                        <div class="bg-white rounded-lg p-4 border border-gray-200 mb-3">
                            <h5 class="font-medium text-gray-900 mb-2">${category.nama}</h5>
                            <p class="text-sm text-gray-600 mb-2">Products: ${category.product_count}</p>
                            <div class="text-xs text-gray-500">
                                Files: ${category.files.join(', ')}
                            </div>
                        </div>
                    `;
                });
                
                html += '</div>';
            } else {
                html += '<div class="mt-4 text-center text-gray-500">No products found to convert</div>';
            }
            
            content.innerHTML = html;
            document.getElementById('scan-results').classList.remove('hidden');
        }
        
        // Convert products
        async function convertProducts() {
            if (!scanData) {
                alert('Please scan products first');
                return;
            }
            
            const removeOriginals = document.getElementById('remove-originals').checked;
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=convert&remove_originals=${removeOriginals}`
                });
                
                const result = await response.json();
                if (result.success) {
                    displayConvertResults(result.data);
                } else {
                    alert('Error converting products: ' + result.error);
                }
            } catch (error) {
                console.error('Error converting products:', error);
                alert('Error converting products');
            }
        }
        
        // Display conversion results
        function displayConvertResults(data) {
            const content = document.getElementById('convert-content');
            
            let html = `
                <div class="space-y-4">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div class="flex">
                            <i data-lucide="check-circle" class="w-5 h-5 text-green-600 mr-3 mt-0.5"></i>
                            <div>
                                <h4 class="text-sm font-medium text-green-800">Conversion Successful!</h4>
                                <p class="text-sm text-green-700 mt-1">Products have been converted to katalog format</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 class="font-semibold text-blue-900 mb-2">Backup Information</h4>
                        <p class="text-sm text-blue-700">Backup directory: <code class="bg-blue-100 px-1 rounded">${data.backup.backup_dir}</code></p>
                        <p class="text-sm text-blue-700">Files backed up: ${data.backup.backed_up.length}</p>
                    </div>
            `;
            
            if (Object.keys(data.katalog_files).length > 0) {
                html += '<div class="bg-white border border-gray-200 rounded-lg p-4"><h4 class="font-semibold text-gray-900 mb-3">Created Katalog Files</h4>';
                
                Object.keys(data.katalog_files).forEach(kategori => {
                    const file = data.katalog_files[kategori];
                    html += `
                        <div class="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                            <div>
                                <span class="font-medium">${file.filename}</span>
                                <span class="text-sm text-gray-500 ml-2">(${file.product_count} products)</span>
                            </div>
                            <span class="text-sm ${file.success ? 'text-green-600' : 'text-red-600'}">
                                ${file.success ? '✓ Created' : '✗ Failed'}
                            </span>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            if (data.removed_originals && data.removed_originals.length > 0) {
                html += `
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <h4 class="font-semibold text-yellow-900 mb-2">Removed Original Files</h4>
                        <p class="text-sm text-yellow-700">${data.removed_originals.length} files removed</p>
                    </div>
                `;
            }
            
            html += '</div>';
            
            content.innerHTML = html;
            document.getElementById('convert-results').classList.remove('hidden');
        }
        
        // Initialize Lucide icons
        lucide.createIcons();
    </script>
</body>
</html> 