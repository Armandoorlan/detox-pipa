<?php
/**
 * View Products Script
 * Melihat struktur data produk yang ada (format lama vs format baru)
 */

class ProductViewer {
    private $produk_dir = '../data/produk/';
    private $kategori_layanan = [
        'filter-air' => 'katalog-filter.json',
        'plumbing' => 'katalog-plumbing.json',
        'pompa-air' => 'katalog-pompa-air.json',
        'water-heater' => 'katalog-water-heater.json',
        'pipa-mampet' => 'katalog-pipa-mampet.json',
        'perbaikan' => 'katalog-perbaikan.json'
    ];
    
    /**
     * Get all product files
     */
    public function getAllProductFiles() {
        $files = glob($this->produk_dir . '*.json');
        $result = [
            'individual' => [],
            'katalog' => []
        ];
        
        foreach ($files as $file) {
            $filename = basename($file);
            $filepath = $file;
            $filesize = filesize($file);
            $modified = date('Y-m-d H:i:s', filemtime($file));
            
            $file_info = [
                'filename' => $filename,
                'filepath' => $filepath,
                'filesize' => $filesize,
                'modified' => $modified
            ];
            
            if (strpos($filename, 'katalog-') === 0) {
                $result['katalog'][] = $file_info;
            } else {
                $result['individual'][] = $file_info;
            }
        }
        
        return $result;
    }
    
    /**
     * Load and parse product file
     */
    public function loadProductFile($filepath) {
        if (!file_exists($filepath)) {
            return null;
        }
        
        $content = file_get_contents($filepath);
        $data = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'error' => json_last_error_msg(),
                'raw_content' => substr($content, 0, 500) . '...'
            ];
        }
        
        return $data;
    }
    
    /**
     * Analyze individual product files
     */
    public function analyzeIndividualFiles($files) {
        $analysis = [];
        
        foreach ($files as $file) {
            $data = $this->loadProductFile($file['filepath']);
            
            if (is_array($data)) {
                $analysis[] = [
                    'filename' => $file['filename'],
                    'filesize' => $file['filesize'],
                    'modified' => $file['modified'],
                    'product_id' => $data['id'] ?? 'N/A',
                    'product_name' => $data['nama'] ?? 'N/A',
                    'kategori' => $data['kategori'] ?? 'N/A',
                    'has_harga' => isset($data['harga']),
                    'has_gambar' => isset($data['gambar']),
                    'harga_count' => isset($data['harga']) ? count($data['harga']) : 0,
                    'gambar_count' => isset($data['gambar']) ? count($data['gambar']) : 0,
                    'structure' => $this->analyzeStructure($data)
                ];
            } else {
                $analysis[] = [
                    'filename' => $file['filename'],
                    'filesize' => $file['filesize'],
                    'modified' => $file['modified'],
                    'error' => $data['error'] ?? 'Unknown error',
                    'raw_content' => $data['raw_content'] ?? ''
                ];
            }
        }
        
        return $analysis;
    }
    
    /**
     * Analyze katalog files
     */
    public function analyzeKatalogFiles($files) {
        $analysis = [];
        
        foreach ($files as $file) {
            $data = $this->loadProductFile($file['filepath']);
            
            if (is_array($data)) {
                $analysis[] = [
                    'filename' => $file['filename'],
                    'filesize' => $file['filesize'],
                    'modified' => $file['modified'],
                    'kategori' => $data['kategori'] ?? 'N/A',
                    'nama_kategori' => $data['nama_kategori'] ?? 'N/A',
                    'product_count' => isset($data['produk']) ? count($data['produk']) : 0,
                    'has_metadata' => isset($data['created_at']) || isset($data['updated_at']),
                    'structure' => $this->analyzeStructure($data)
                ];
            } else {
                $analysis[] = [
                    'filename' => $file['filename'],
                    'filesize' => $file['filesize'],
                    'modified' => $file['modified'],
                    'error' => $data['error'] ?? 'Unknown error',
                    'raw_content' => $data['raw_content'] ?? ''
                ];
            }
        }
        
        return $analysis;
    }
    
    /**
     * Analyze data structure
     */
    private function analyzeStructure($data) {
        $structure = [];
        
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $structure[$key] = [
                    'type' => 'array',
                    'count' => count($value),
                    'sample_keys' => array_slice(array_keys($value), 0, 3)
                ];
            } else {
                $structure[$key] = [
                    'type' => gettype($value),
                    'value' => is_string($value) ? substr($value, 0, 50) : $value
                ];
            }
        }
        
        return $structure;
    }
    
    /**
     * Get conversion recommendations
     */
    public function getConversionRecommendations($individual_files, $katalog_files) {
        $recommendations = [];
        
        if (count($individual_files) > 0 && count($katalog_files) === 0) {
            $recommendations[] = [
                'type' => 'convert',
                'message' => 'Found individual product files. Recommend converting to katalog format.',
                'action' => 'Run conversion script'
            ];
        } elseif (count($individual_files) > 0 && count($katalog_files) > 0) {
            $recommendations[] = [
                'type' => 'cleanup',
                'message' => 'Found both individual and katalog files. Consider removing individual files.',
                'action' => 'Review and cleanup'
            ];
        } elseif (count($individual_files) === 0 && count($katalog_files) > 0) {
            $recommendations[] = [
                'type' => 'ready',
                'message' => 'All products are in katalog format. Ready to use.',
                'action' => 'Use product manager'
            ];
        } else {
            $recommendations[] = [
                'type' => 'empty',
                'message' => 'No product files found. Start by creating products.',
                'action' => 'Create products'
            ];
        }
        
        return $recommendations;
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $viewer = new ProductViewer();
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'analyze':
                $files = $viewer->getAllProductFiles();
                $individual_analysis = $viewer->analyzeIndividualFiles($files['individual']);
                $katalog_analysis = $viewer->analyzeKatalogFiles($files['katalog']);
                $recommendations = $viewer->getConversionRecommendations($files['individual'], $files['katalog']);
                
                echo json_encode([
                    'success' => true,
                    'data' => [
                        'files' => $files,
                        'individual_analysis' => $individual_analysis,
                        'katalog_analysis' => $katalog_analysis,
                        'recommendations' => $recommendations
                    ]
                ]);
                break;
                
            default:
                echo json_encode(['success' => false, 'error' => 'Invalid action']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products - BersihPipa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h1 class="text-2xl font-bold text-gray-900">Product Data Analysis</h1>
                    <p class="text-gray-600 mt-2">Analyze current product data structure and get conversion recommendations</p>
                </div>
                
                <div class="p-6">
                    <!-- Analyze Button -->
                    <div class="mb-6">
                        <button onclick="analyzeProducts()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            <i data-lucide="search" class="w-4 h-4 inline mr-2"></i>
                            Analyze Products
                        </button>
                    </div>
                    
                    <!-- Analysis Results -->
                    <div id="analysis-results" class="hidden space-y-6">
                        <!-- Recommendations -->
                        <div id="recommendations-section" class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <h3 class="text-lg font-semibold text-blue-900 mb-3">Recommendations</h3>
                            <div id="recommendations-content"></div>
                        </div>
                        
                        <!-- File Summary -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-gray-900 mb-3">Individual Files</h3>
                                <div id="individual-summary"></div>
                            </div>
                            
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-gray-900 mb-3">Katalog Files</h3>
                                <div id="katalog-summary"></div>
                            </div>
                        </div>
                        
                        <!-- Detailed Analysis -->
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-gray-900 mb-3">Individual Files Analysis</h3>
                                <div id="individual-analysis" class="max-h-96 overflow-y-auto"></div>
                            </div>
                            
                            <div class="bg-white border border-gray-200 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-gray-900 mb-3">Katalog Files Analysis</h3>
                                <div id="katalog-analysis" class="max-h-96 overflow-y-auto"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Analyze products
        async function analyzeProducts() {
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=analyze'
                });
                
                const result = await response.json();
                if (result.success) {
                    displayAnalysisResults(result.data);
                } else {
                    alert('Error analyzing products: ' + result.error);
                }
            } catch (error) {
                console.error('Error analyzing products:', error);
                alert('Error analyzing products');
            }
        }
        
        // Display analysis results
        function displayAnalysisResults(data) {
            displayRecommendations(data.recommendations);
            displayFileSummary(data.files);
            displayIndividualAnalysis(data.individual_analysis);
            displayKatalogAnalysis(data.katalog_analysis);
            
            document.getElementById('analysis-results').classList.remove('hidden');
        }
        
        // Display recommendations
        function displayRecommendations(recommendations) {
            const content = document.getElementById('recommendations-content');
            
            let html = '';
            recommendations.forEach(rec => {
                const iconClass = {
                    'convert': 'text-blue-600',
                    'cleanup': 'text-yellow-600',
                    'ready': 'text-green-600',
                    'empty': 'text-gray-600'
                }[rec.type] || 'text-gray-600';
                
                const iconName = {
                    'convert': 'refresh-cw',
                    'cleanup': 'trash-2',
                    'ready': 'check-circle',
                    'empty': 'plus-circle'
                }[rec.type] || 'info';
                
                html += `
                    <div class="flex items-start mb-3 last:mb-0">
                        <i data-lucide="${iconName}" class="w-5 h-5 ${iconClass} mr-3 mt-0.5"></i>
                        <div>
                            <p class="text-sm font-medium text-gray-900">${rec.message}</p>
                            <p class="text-sm text-gray-600">Action: ${rec.action}</p>
                        </div>
                    </div>
                `;
            });
            
            content.innerHTML = html;
        }
        
        // Display file summary
        function displayFileSummary(files) {
            // Individual files summary
            const individualSummary = document.getElementById('individual-summary');
            individualSummary.innerHTML = `
                <div class="text-3xl font-bold text-blue-600">${files.individual.length}</div>
                <div class="text-sm text-gray-600">Individual product files</div>
                <div class="text-xs text-gray-500 mt-1">
                    Total size: ${formatBytes(files.individual.reduce((sum, f) => sum + f.filesize, 0))}
                </div>
            `;
            
            // Katalog files summary
            const katalogSummary = document.getElementById('katalog-summary');
            katalogSummary.innerHTML = `
                <div class="text-3xl font-bold text-green-600">${files.katalog.length}</div>
                <div class="text-sm text-gray-600">Katalog files</div>
                <div class="text-xs text-gray-500 mt-1">
                    Total size: ${formatBytes(files.katalog.reduce((sum, f) => sum + f.filesize, 0))}
                </div>
            `;
        }
        
        // Display individual analysis
        function displayIndividualAnalysis(analysis) {
            const content = document.getElementById('individual-analysis');
            
            if (analysis.length === 0) {
                content.innerHTML = '<p class="text-gray-500 text-center py-4">No individual files found</p>';
                return;
            }
            
            let html = '';
            analysis.forEach(item => {
                if (item.error) {
                    html += `
                        <div class="border border-red-200 rounded-lg p-3 mb-3">
                            <div class="font-medium text-red-800">${item.filename}</div>
                            <div class="text-sm text-red-600">Error: ${item.error}</div>
                        </div>
                    `;
                } else {
                    html += `
                        <div class="border border-gray-200 rounded-lg p-3 mb-3">
                            <div class="font-medium text-gray-900">${item.product_name}</div>
                            <div class="text-sm text-gray-600">ID: ${item.product_id}</div>
                            <div class="text-sm text-gray-600">Category: ${item.kategori}</div>
                            <div class="text-xs text-gray-500 mt-1">
                                Harga: ${item.harga_count} cities | 
                                Images: ${item.gambar_count} files |
                                Size: ${formatBytes(item.filesize)}
                            </div>
                        </div>
                    `;
                }
            });
            
            content.innerHTML = html;
        }
        
        // Display katalog analysis
        function displayKatalogAnalysis(analysis) {
            const content = document.getElementById('katalog-analysis');
            
            if (analysis.length === 0) {
                content.innerHTML = '<p class="text-gray-500 text-center py-4">No katalog files found</p>';
                return;
            }
            
            let html = '';
            analysis.forEach(item => {
                if (item.error) {
                    html += `
                        <div class="border border-red-200 rounded-lg p-3 mb-3">
                            <div class="font-medium text-red-800">${item.filename}</div>
                            <div class="text-sm text-red-600">Error: ${item.error}</div>
                        </div>
                    `;
                } else {
                    html += `
                        <div class="border border-gray-200 rounded-lg p-3 mb-3">
                            <div class="font-medium text-gray-900">${item.nama_kategori}</div>
                            <div class="text-sm text-gray-600">Category: ${item.kategori}</div>
                            <div class="text-sm text-gray-600">Products: ${item.product_count}</div>
                            <div class="text-xs text-gray-500 mt-1">
                                Size: ${formatBytes(item.filesize)} |
                                Modified: ${item.modified}
                            </div>
                        </div>
                    `;
                }
            });
            
            content.innerHTML = html;
        }
        
        // Format bytes
        function formatBytes(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Initialize Lucide icons
        lucide.createIcons();
    </script>
</body>
</html> 