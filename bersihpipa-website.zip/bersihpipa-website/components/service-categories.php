<?php
// Service Categories Component - BersihPipa.com
?>
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Kategori Layanan Kami</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                Solusi lengkap untuk semua kebutuhan air dan instalasi pipa Anda
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Detox & Bersih Pipa -->
            <div class="group relative bg-gradient-to-br from-blue-50 to-blue-100 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 cursor-pointer border border-blue-200 hover:border-blue-300">
                <!-- Background Pattern -->
                <div class="absolute inset-0 bg-gradient-to-br from-blue-400/5 to-blue-600/10 rounded-3xl"></div>
                
                <!-- Icon Container -->
                <div class="relative z-10 w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <i data-lucide="droplets" class="w-10 h-10 text-white"></i>
                </div>

                <!-- Content -->
                <div class="relative z-10 text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-700 transition-colors">
                        Detox & Bersih Pipa
                    </h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Pembersihan pipa tanpa bongkar dengan teknologi canggih untuk mengatasi pipa mampet dan air kotor
                    </p>
                    
                    <!-- Features -->
                    <ul class="text-sm text-gray-600 space-y-2 mb-6">
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Tanpa Bongkar
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Teknologi Modern
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Garansi Hasil
                        </li>
                    </ul>

                    <!-- Price Badge -->
                    <div class="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 inline-block">
                        Mulai Rp 150.000
                    </div>

                    <!-- CTA Button -->
                    <button onclick="serviceWhatsApp('detox-pipa')" 
                            class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105">
                        <i data-lucide="message-circle" class="h-4 w-4 mr-2 inline"></i>
                        Konsultasi Gratis
                    </button>
                </div>

                <!-- Hover Effect Overlay -->
                <div class="absolute inset-0 bg-gradient-to-br from-blue-600/0 to-blue-600/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>

            <!-- Tukang Sumur -->
            <div class="group relative bg-gradient-to-br from-green-50 to-green-100 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 cursor-pointer border border-green-200 hover:border-green-300">
                <!-- Background Pattern -->
                <div class="absolute inset-0 bg-gradient-to-br from-green-400/5 to-green-600/10 rounded-3xl"></div>
                
                <!-- Icon Container -->
                <div class="relative z-10 w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <i data-lucide="hammer" class="w-10 h-10 text-white"></i>
                </div>

                <!-- Content -->
                <div class="relative z-10 text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-4 group-hover:text-green-700 transition-colors">
                        Tukang Sumur
                    </h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Jasa pembuatan sumur bor, sumur gali, dan perawatan sumur dengan peralatan modern dan berpengalaman
                    </p>
                    
                    <!-- Features -->
                    <ul class="text-sm text-gray-600 space-y-2 mb-6">
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Sumur Bor & Gali
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Peralatan Modern
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Berpengalaman
                        </li>
                    </ul>

                    <!-- Price Badge -->
                    <div class="bg-green-600 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 inline-block">
                        Survey Gratis
                    </div>

                    <!-- CTA Button -->
                    <button onclick="serviceWhatsApp('tukang-sumur')" 
                            class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105">
                        <i data-lucide="message-circle" class="h-4 w-4 mr-2 inline"></i>
                        Konsultasi Gratis
                    </button>
                </div>

                <!-- Hover Effect Overlay -->
                <div class="absolute inset-0 bg-gradient-to-br from-green-600/0 to-green-600/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>

            <!-- Plumbing -->
            <div class="group relative bg-gradient-to-br from-purple-50 to-purple-100 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 cursor-pointer border border-purple-200 hover:border-purple-300">
                <!-- Background Pattern -->
                <div class="absolute inset-0 bg-gradient-to-br from-purple-400/5 to-purple-600/10 rounded-3xl"></div>
                
                <!-- Icon Container -->
                <div class="relative z-10 w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <i data-lucide="wrench" class="w-10 h-10 text-white"></i>
                </div>

                <!-- Content -->
                <div class="relative z-10 text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-4 group-hover:text-purple-700 transition-colors">
                        Plumbing
                    </h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Layanan perbaikan dan instalasi sistem perpipaan, keran, toilet, dan semua kebutuhan plumbing rumah
                    </p>
                    
                    <!-- Features -->
                    <ul class="text-sm text-gray-600 space-y-2 mb-6">
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Perbaikan Keran
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Instalasi Toilet
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Sistem Perpipaan
                        </li>
                    </ul>

                    <!-- Price Badge -->
                    <div class="bg-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 inline-block">
                        Panggilan 24/7
                    </div>

                    <!-- CTA Button -->
                    <button onclick="serviceWhatsApp('plumbing')" 
                            class="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-xl font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105">
                        <i data-lucide="message-circle" class="h-4 w-4 mr-2 inline"></i>
                        Konsultasi Gratis
                    </button>
                </div>

                <!-- Hover Effect Overlay -->
                <div class="absolute inset-0 bg-gradient-to-br from-purple-600/0 to-purple-600/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>

            <!-- Instalasi Pompa -->
            <div class="group relative bg-gradient-to-br from-orange-50 to-orange-100 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 cursor-pointer border border-orange-200 hover:border-orange-300">
                <!-- Background Pattern -->
                <div class="absolute inset-0 bg-gradient-to-br from-orange-400/5 to-orange-600/10 rounded-3xl"></div>
                
                <!-- Icon Container -->
                <div class="relative z-10 w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <i data-lucide="settings" class="w-10 h-10 text-white"></i>
                </div>

                <!-- Content -->
                <div class="relative z-10 text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-4 group-hover:text-orange-700 transition-colors">
                        Instalasi Pompa
                    </h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Pemasangan dan perbaikan pompa air, pompa sumur, pressure tank untuk kebutuhan air rumah tangga
                    </p>
                    
                    <!-- Features -->
                    <ul class="text-sm text-gray-600 space-y-2 mb-6">
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Pompa Air & Sumur
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Pressure Tank
                        </li>
                        <li class="flex items-center justify-center">
                            <i data-lucide="check-circle" class="h-4 w-4 text-green-500 mr-2"></i>
                            Service & Maintenance
                        </li>
                    </ul>

                    <!-- Price Badge -->
                    <div class="bg-orange-600 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 inline-block">
                        Garansi Service
                    </div>

                    <!-- CTA Button -->
                    <button onclick="serviceWhatsApp('instalasi-pompa')" 
                            class="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-xl font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105">
                        <i data-lucide="message-circle" class="h-4 w-4 mr-2 inline"></i>
                        Konsultasi Gratis
                    </button>
                </div>

                <!-- Hover Effect Overlay -->
                <div class="absolute inset-0 bg-gradient-to-br from-orange-600/0 to-orange-600/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
        </div>

        <!-- Bottom CTA Section -->
        <div class="text-center mt-16">
            <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-3xl p-8 shadow-lg border border-blue-100">
                <h3 class="text-2xl font-bold text-gray-900 mb-4">Tidak Yakin Layanan Mana yang Anda Butuhkan?</h3>
                <p class="text-gray-600 mb-6 max-w-2xl mx-auto">
                    Tim ahli kami siap membantu Anda menentukan solusi terbaik untuk kebutuhan air dan instalasi pipa Anda
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="https://wa.me/6281236937200?text=Halo%20FLUKS%20Water%20Treatment,%20saya%20butuh%20konsultasi%20untuk%20menentukan%20layanan%20yang%20tepat" 
                       target="_blank" 
                       class="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                        <i data-lucide="phone-call" class="h-5 w-5 mr-2"></i>
                        Konsultasi Gratis Sekarang
                    </a>
                    <button onclick="scrollToSection('hitung-biaya')" 
                            class="inline-flex items-center bg-white hover:bg-gray-50 text-blue-600 border-2 border-blue-600 px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                        <i data-lucide="calculator" class="h-5 w-5 mr-2"></i>
                        Hitung Estimasi Biaya
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Service WhatsApp Contact Function
function serviceWhatsApp(serviceType) {
    const services = {
        'detox-pipa': {
            title: 'Detox & Bersih Pipa',
            message: 'Halo FLUKS Water Treatment, saya tertarik dengan layanan Detox & Bersih Pipa. Mohon info lebih lanjut mengenai:'
        },
        'tukang-sumur': {
            title: 'Tukang Sumur',
            message: 'Halo FLUKS Water Treatment, saya tertarik dengan layanan Tukang Sumur. Mohon info lebih lanjut mengenai:'
        },
        'plumbing': {
            title: 'Plumbing',
            message: 'Halo FLUKS Water Treatment, saya tertarik dengan layanan Plumbing. Mohon info lebih lanjut mengenai:'
        },
        'instalasi-pompa': {
            title: 'Instalasi Pompa',
            message: 'Halo FLUKS Water Treatment, saya tertarik dengan layanan Instalasi Pompa. Mohon info lebih lanjut mengenai:'
        }
    };

    const service = services[serviceType];
    if (!service) return;

    const currentUrl = window.location.href;
    const fullMessage = `${service.message}

📋 *Layanan: ${service.title}*

• Harga dan paket yang tersedia
• Waktu pengerjaan
• Area layanan
• Garansi yang diberikan

📱 Dikirim dari: ${currentUrl}

Terima kasih! 🙏`;

    const whatsappUrl = `https://wa.me/6281236937200?text=${encodeURIComponent(fullMessage)}`;
    window.open(whatsappUrl, '_blank');
}

// Make function globally available
window.serviceWhatsApp = serviceWhatsApp;
</script>

<style>
/* Additional animations for service cards */
@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
}

.group:hover .animate-float {
    animation: float 2s ease-in-out infinite;
}

/* Gradient text effect for service titles */
.service-gradient-text {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Custom scrollbar for better UX */
.service-card::-webkit-scrollbar {
    width: 4px;
}

.service-card::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 2px;
}

.service-card::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 2px;
}

.service-card::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
}
</style>
