<?php
/**
 * Product Helper Functions
 * Untuk mengelola data produk dari JSON files dengan dukungan multi-kota
 */

class ProductHelper {
    private $data_path;
    
    public function __construct($data_path = '../data/') {
        $this->data_path = $data_path;
    }
    
    /**
     * Load product data by ID and cabang
     */
    public function getProductById($product_id, $cabang = 'malang') {
        // First try to load from produk directory (new structure)
        $produk_file = $this->findProductFile($product_id);
        if ($produk_file) {
            $data = json_decode(file_get_contents($produk_file), true);
            if ($data && isset($data['id']) && $data['id'] === $product_id) {
                // Add cabang-specific data
                $data['cabang_data'] = $this->getCabangSpecificData($data, $cabang);
                return $data;
            }
        }
        
        // Fallback to layanan directory (old structure)
        return $this->getProductFromLayanan($product_id, $cabang);
    }
    
    /**
     * Find product file by ID
     */
    private function findProductFile($product_id) {
        $produk_dir = $this->data_path . 'produk/';
        if (!is_dir($produk_dir)) {
            return null;
        }
        
        $files = glob($produk_dir . '*.json');
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if ($data && isset($data['id']) && $data['id'] === $product_id) {
                return $file;
            }
        }
        
        return null;
    }
    
    /**
     * Get cabang-specific data from product
     */
    private function getCabangSpecificData($product, $cabang) {
        if (!isset($product['harga'][$cabang])) {
            // Fallback to default cabang
            $default_cabang = $this->getDefaultCabang();
            if (isset($product['harga'][$default_cabang])) {
                return [
                    'harga' => $product['harga'][$default_cabang],
                    'status' => 'fallback'
                ];
            }
            return null;
        }
        
        return [
            'harga' => $product['harga'][$cabang],
            'status' => 'tersedia'
        ];
    }
    
    /**
     * Get product from layanan directory (legacy support)
     */
    private function getProductFromLayanan($product_id, $cabang) {
        $layanan_files = [
            'filter-air.json',
            'pipa-mampet.json',
            'plumbing.json',
            'pompa-air.json',
            'water-heater.json',
            'perbaikan.json'
        ];
        
        foreach ($layanan_files as $file) {
            $file_path = $this->data_path . 'layanan/' . $file;
            if (file_exists($file_path)) {
                $data = json_decode(file_get_contents($file_path), true);
                
                if (isset($data['layanan']['produk'])) {
                    foreach ($data['layanan']['produk'] as $key => $product) {
                        if (isset($product['id']) && $product['id'] === $product_id) {
                            $product['layanan_info'] = [
                                'id' => $data['layanan']['id'],
                                'nama' => $data['layanan']['nama'],
                                'kategori' => $data['layanan']['kategori'],
                                'deskripsi' => $data['layanan']['deskripsi'],
                                'icon' => $data['layanan']['icon'],
                                'gambar' => $data['layanan']['gambar']
                            ];
                            
                            if (isset($data['layanan']['cabang'][$cabang])) {
                                $product['cabang_data'] = $data['layanan']['cabang'][$cabang];
                            }
                            
                            return $product;
                        }
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Get all products from a specific layanan
     */
    public function getProductsByLayanan($layanan_id, $cabang = 'malang') {
        $products = [];
        
        // Get from produk directory first
        $produk_dir = $this->data_path . 'produk/';
        if (is_dir($produk_dir)) {
            $files = glob($produk_dir . '*.json');
            foreach ($files as $file) {
                $data = json_decode(file_get_contents($file), true);
                if ($data && isset($data['kategori']) && $data['kategori'] === $layanan_id) {
                    $data['cabang_data'] = $this->getCabangSpecificData($data, $cabang);
                    $products[] = $data;
                }
            }
        }
        
        // If no products found, try layanan directory
        if (empty($products)) {
            $file_path = $this->data_path . 'layanan/' . $layanan_id . '.json';
            
            if (file_exists($file_path)) {
                $data = json_decode(file_get_contents($file_path), true);
                
                if (isset($data['layanan']['produk'])) {
                    foreach ($data['layanan']['produk'] as $key => $product) {
                        $product['layanan_info'] = [
                            'id' => $data['layanan']['id'],
                            'nama' => $data['layanan']['nama'],
                            'kategori' => $data['layanan']['kategori']
                        ];
                        
                        if (isset($data['layanan']['cabang'][$cabang])) {
                            $product['cabang_data'] = $data['layanan']['cabang'][$cabang];
                        }
                        
                        $products[] = $product;
                    }
                }
            }
        }
        
        return $products;
    }
    
    /**
     * Get cabang data
     */
    public function getCabangData($cabang_id = null) {
        $file_path = $this->data_path . 'data-master/cabang.json';
        
        if (!file_exists($file_path)) {
            return null;
        }
        
        $data = json_decode(file_get_contents($file_path), true);
        
        if ($cabang_id) {
            foreach ($data['cabang'] as $cabang) {
                if ($cabang['id'] === $cabang_id) {
                    return $cabang;
                }
            }
            return null;
        }
        
        return $data['cabang'];
    }
    
    /**
     * Get kategori layanan
     */
    public function getKategoriLayanan() {
        $file_path = $this->data_path . 'data-master/kategori-layanan.json';
        
        if (!file_exists($file_path)) {
            return [];
        }
        
        $data = json_decode(file_get_contents($file_path), true);
        return $data['kategori'] ?? [];
    }
    
    /**
     * Get product price for specific cabang
     */
    public function getProductPrice($product_id, $cabang = 'malang') {
        $product = $this->getProductById($product_id, $cabang);
        
        if (!$product) {
            return null;
        }
        
        // New structure (produk directory)
        if (isset($product['harga'][$cabang])) {
            return $product['harga'][$cabang];
        }
        
        // Legacy structure (layanan directory)
        if (isset($product['cabang_data']['harga'])) {
            foreach ($product['cabang_data']['harga'] as $key => $harga_data) {
                if (strpos($key, $product_id) !== false || $key === $product_id) {
                    return $harga_data;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Get related products
     */
    public function getRelatedProducts($product_id, $limit = 4) {
        $current_product = $this->getProductById($product_id);
        
        if (!$current_product) {
            return [];
        }
        
        $kategori = $current_product['kategori'] ?? $current_product['layanan_info']['kategori'] ?? null;
        
        if (!$kategori) {
            return [];
        }
        
        $all_products = $this->getProductsByLayanan($kategori);
        
        // Filter out current product and limit results
        $related = array_filter($all_products, function($product) use ($product_id) {
            $productIdToCheck = $product['id'] ?? ($product['layanan_info']['id'] ?? null);
            return $productIdToCheck !== $product_id;
        });
        
        return array_slice($related, 0, $limit);
    }
    
    /**
     * Format price to Indonesian Rupiah
     */
    public function formatPrice($price) {
        return 'Rp' . number_format($price, 0, ',', '.');
    }
    
    /**
     * Calculate installment
     */
    public function calculateInstallment($price, $months = 12) {
        return [
            'monthly' => $price / $months,
            'total_months' => $months,
            'formatted_monthly' => $this->formatPrice($price / $months)
        ];
    }
    
    /**
     * Get product images for carousel
     */
    public function getProductImages($product) {
        $images = [];
        
        // New structure
        if (isset($product['gambar']) && is_array($product['gambar'])) {
            $images = $product['gambar'];
        } elseif (isset($product['gambar'])) {
            $images[] = $product['gambar'];
        }
        
        // Legacy structure
        if (empty($images) && isset($product['images']) && is_array($product['images'])) {
            $images = $product['images'];
        }
        
        // Validate and fix image paths
        $valid_images = [];
        foreach ($images as $image) {
            // If it's already a full path, use as is
            if (strpos($image, '/') === 0) {
                $valid_images[] = $image;
            } else {
                // Assume it's a filename in katalog-filter folder
                $valid_images[] = '/upload/katalog-filter/' . urlencode($image);
            }
        }
        
        // Fallback
        if (empty($valid_images)) {
            $valid_images[] = '/placeholder.jpg';
        }
        
        return $valid_images;
    }
    
    /**
     * Check if cabang is valid
     */
    public function isValidCabang($cabang) {
        $cabang_data = $this->getCabangData();
        if (!$cabang_data) {
            return false;
        }
        
        foreach ($cabang_data as $cab) {
            if ($cab['id'] === $cabang && $cab['status'] === 'aktif') {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get default cabang
     */
    public function getDefaultCabang() {
        return 'malang';
    }
}

// Legacy function wrappers for backward compatibility
function get_product_by_id($product_id, $cabang = 'malang') {
    $helper = new ProductHelper();
    return $helper->getProductById($product_id, $cabang);
}

function get_cabang_data($cabang_id = null) {
    $helper = new ProductHelper();
    return $helper->getCabangData($cabang_id);
}

function format_price($price) {
    $helper = new ProductHelper();
    return $helper->formatPrice($price);
}

function calculate_installment($price, $months = 12) {
    $helper = new ProductHelper();
    return $helper->calculateInstallment($price, $months);
}
?> 