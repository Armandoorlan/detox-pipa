<?php
/**
 * Cabang Selector Component
 * Komponen untuk memilih cabang/lokasi layanan
 */

require_once 'product-helper.php';

class CabangSelector {
    private $helper;
    
    public function __construct() {
        $this->helper = new ProductHelper();
    }
    
    /**
     * Render cabang selector modal
     */
    public static function renderModal($selected_cabang) {
        ?>
        <!-- Cabang Selector Modal -->
        <div id="cabangModal" class="fixed inset-0 bg-black/50 z-50 hidden">
            <div class="flex items-end justify-center min-h-screen p-4">
                <div class="bg-white rounded-t-xl w-full max-w-md max-h-[80vh] overflow-hidden">
                    <!-- Modal Header -->
                    <div class="flex items-center justify-between p-3 border-b border-surface-200">
                        <h3 class="text-sm font-semibold text-surface-900">Pilih Cabang</h3>
                        <button onclick="closeCabangModal()" class="w-6 h-6 bg-surface-100 rounded-lg flex items-center justify-center">
                            <i data-lucide="x" class="w-4 h-4 text-surface-600"></i>
                        </button>
                    </div>
                    
                    <!-- Modal Content -->
                    <div class="p-3 space-y-2 max-h-96 overflow-y-auto">
                        <?php
                        $cabang_list = [
                            'malang' => 'Malang',
                            'surabaya' => 'Surabaya',
                            'jakarta' => 'Jakarta',
                            'bandung' => 'Bandung',
                            'semarang' => 'Semarang'
                        ];
                        
                        foreach($cabang_list as $cabang_id => $cabang_name):
                        ?>
                        <button onclick="selectCabang('<?= $cabang_id ?>')" 
                                class="w-full flex items-center justify-between p-2 rounded-lg hover:bg-surface-50 transition-colors <?= $selected_cabang === $cabang_id ? 'bg-primary-50 border border-primary-200' : '' ?>">
                            <div class="flex items-center space-x-2">
                                <i data-lucide="map-pin" class="w-4 h-4 text-primary-600"></i>
                                <span class="text-sm text-surface-900"><?= $cabang_name ?></span>
                            </div>
                            <?php if($selected_cabang === $cabang_id): ?>
                            <i data-lucide="check" class="w-4 h-4 text-primary-600"></i>
                            <?php endif; ?>
                        </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render cabang selector button
     */
    public static function renderButton($selected_cabang, $cabang_data) {
        ?>
        <button onclick="openCabangModal()" class="flex items-center space-x-1 px-2 py-1 bg-surface-100 hover:bg-surface-200 rounded-lg text-xs font-medium transition-all">
            <i data-lucide="map-pin" class="w-3 h-3 text-primary-600"></i>
            <span class="text-surface-700"><?= ucfirst($selected_cabang) ?></span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-surface-500"></i>
        </button>
        <?php
    }
    
    /**
     * Render cabang info card
     */
    public function renderInfoCard($cabang_id = 'malang') {
        $cabang_data = $this->helper->getCabangData($cabang_id);
        if (!$cabang_data) return;
        ?>
        <div class="bg-surface-50 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
                        <i data-lucide="store" class="w-5 h-5 text-primary-600"></i>
                    </div>
                    <div>
                        <div class="font-semibold text-surface-900">BersihPipa.com - <?= $cabang_data['nama'] ?></div>
                        <div class="text-sm text-surface-600">Online</div>
                    </div>
                </div>
                <button class="px-4 py-2 border border-primary-600 text-primary-600 rounded-lg text-sm font-medium hover:bg-primary-50 transition-colors">
                    Follow
                </button>
            </div>
            
            <!-- Store Location -->
            <div class="flex items-start space-x-2">
                <i data-lucide="map-pin" class="w-4 h-4 text-surface-500 mt-0.5 flex-shrink-0"></i>
                <div class="text-sm text-surface-600 line-clamp-2">
                    <?= $cabang_data['alamat'] ?>
                </div>
            </div>
            
            <!-- Store Hours -->
            <div class="flex items-center space-x-2">
                <i data-lucide="clock" class="w-4 h-4 text-surface-500"></i>
                <div class="text-sm text-surface-600">
                    Buka <?= $cabang_data['jam_operasional']['senin_jumat'] ?>
                </div>
            </div>
            
            <!-- Contact Info -->
            <div class="flex items-center space-x-2">
                <i data-lucide="phone" class="w-4 h-4 text-surface-500"></i>
                <div class="text-sm text-surface-600">
                    <?= $cabang_data['kontak']['telepon'] ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render cabang selector JavaScript
     */
    public static function renderScript() {
        ?>
        <script>
            function openCabangModal() {
                document.getElementById('cabangModal').classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }

            function closeCabangModal() {
                document.getElementById('cabangModal').classList.add('hidden');
                document.body.style.overflow = 'auto';
            }

            function selectCabang(cabangId) {
                const currentUrl = new URL(window.location);
                currentUrl.searchParams.set('cabang', cabangId);
                window.location.href = currentUrl.toString();
            }

            // Close modal when clicking outside
            document.getElementById('cabangModal')?.addEventListener('click', function(e) {
                if (e.target === this) {
                    closeCabangModal();
                }
            });
        </script>
        <?php
    }
}

// Helper function for easy access
function render_cabang_selector($selected_cabang = 'malang') {
    $selector = new CabangSelector();
    $selector->renderButton($selected_cabang);
}

function render_cabang_modal() {
    $selector = new CabangSelector();
    $selector->renderModal();
}

function render_cabang_info($cabang_id = 'malang') {
    $selector = new CabangSelector();
    $selector->renderInfoCard($cabang_id);
}

function get_cabang_javascript() {
    $selector = new CabangSelector();
    $selector->getJavaScript();
}
?> 