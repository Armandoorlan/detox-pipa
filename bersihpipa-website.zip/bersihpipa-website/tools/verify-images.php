<?php
/**
 * Image Verification Tool
 * Script untuk memverifikasi bahwa semua gambar produk dapat diakses
 */

require_once '../includes/product-helper.php';

$helper = new ProductHelper();
$products = $helper->getProductsByLayanan('filter-air', 'malang');

function checkImageAccess($image_path) {
    $full_path = $_SERVER['DOCUMENT_ROOT'] . $image_path;
    $web_path = 'http://' . $_SERVER['HTTP_HOST'] . $image_path;
    
    $file_exists = file_exists($full_path);
    $file_size = $file_exists ? filesize($full_path) : 0;
    
    // Check if image is accessible via web
    $headers = @get_headers($web_path);
    $web_accessible = $headers && strpos($headers[0], '200') !== false;
    
    return [
        'file_exists' => $file_exists,
        'file_size' => $file_size,
        'web_accessible' => $web_accessible,
        'web_path' => $web_path,
        'full_path' => $full_path
    ];
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Verification - BersihPipa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .product-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .image-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            background: #f9f9f9;
        }
        .status-ok {
            border-left: 4px solid #28a745;
            background: #d4edda;
        }
        .status-error {
            border-left: 4px solid #dc3545;
            background: #f8d7da;
        }
        .status-warning {
            border-left: 4px solid #ffc107;
            background: #fff3cd;
        }
        .image-preview {
            max-width: 200px;
            max-height: 150px;
            object-fit: cover;
            border-radius: 4px;
            margin: 10px 0;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin: 10px 0;
        }
        .info-item {
            background: white;
            padding: 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .summary {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        .summary-item {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .summary-number {
            font-size: 24px;
            font-weight: bold;
        }
        .number-ok { color: #28a745; }
        .number-error { color: #dc3545; }
        .number-warning { color: #ffc107; }
        .summary-label {
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Image Verification Tool - BersihPipa</h1>
        
        <?php
        $total_images = 0;
        $accessible_images = 0;
        $file_exists_count = 0;
        $web_accessible_count = 0;
        $errors = [];
        
        foreach ($products as $product) {
            $images = $helper->getProductImages($product);
            $total_images += count($images);
            
            foreach ($images as $image) {
                $check = checkImageAccess($image);
                
                if ($check['file_exists']) $file_exists_count++;
                if ($check['web_accessible']) $web_accessible_count++;
                if ($check['file_exists'] && $check['web_accessible']) $accessible_images++;
                
                if (!$check['file_exists'] || !$check['web_accessible']) {
                    $errors[] = [
                        'product' => $product['nama'],
                        'image' => $image,
                        'check' => $check
                    ];
                }
            }
        }
        ?>
        
        <div class="summary">
            <h2>Summary</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-number"><?= $total_images ?></div>
                    <div class="summary-label">Total Images</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number number-ok"><?= $accessible_images ?></div>
                    <div class="summary-label">Fully Accessible</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number number-warning"><?= $file_exists_count - $accessible_images ?></div>
                    <div class="summary-label">File Exists Only</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number number-error"><?= $total_images - $file_exists_count ?></div>
                    <div class="summary-label">Missing Files</div>
                </div>
            </div>
        </div>
        
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <h3><?= htmlspecialchars($product['nama']) ?> (ID: <?= $product['id'] ?>)</h3>
                
                <?php 
                $images = $helper->getProductImages($product);
                foreach ($images as $image): 
                    $check = checkImageAccess($image);
                    $status_class = '';
                    
                    if ($check['file_exists'] && $check['web_accessible']) {
                        $status_class = 'status-ok';
                        $status_text = '✅ Accessible';
                    } elseif ($check['file_exists']) {
                        $status_class = 'status-warning';
                        $status_text = '⚠️ File exists but not web accessible';
                    } else {
                        $status_class = 'status-error';
                        $status_text = '❌ File not found';
                    }
                ?>
                    <div class="image-item <?= $status_class ?>">
                        <h4><?= htmlspecialchars(basename($image)) ?></h4>
                        <p><strong>Status:</strong> <?= $status_text ?></p>
                        
                        <?php if ($check['web_accessible']): ?>
                            <img src="<?= $check['web_path'] ?>" alt="Preview" class="image-preview">
                        <?php endif; ?>
                        
                        <div class="info-grid">
                            <div class="info-item">
                                <strong>File Path:</strong><br>
                                <?= htmlspecialchars($check['full_path']) ?>
                            </div>
                            <div class="info-item">
                                <strong>Web URL:</strong><br>
                                <a href="<?= $check['web_path'] ?>" target="_blank"><?= $check['web_path'] ?></a>
                            </div>
                            <div class="info-item">
                                <strong>File Size:</strong><br>
                                <?= $check['file_size'] ? number_format($check['file_size']) . ' bytes' : 'N/A' ?>
                            </div>
                            <div class="info-item">
                                <strong>File Exists:</strong><br>
                                <?= $check['file_exists'] ? 'Yes' : 'No' ?>
                            </div>
                            <div class="info-item">
                                <strong>Web Accessible:</strong><br>
                                <?= $check['web_accessible'] ? 'Yes' : 'No' ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="product-card">
                <h3>Issues Found</h3>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li>
                            <strong><?= htmlspecialchars($error['product']) ?></strong>: 
                            <?= htmlspecialchars($error['image']) ?>
                            <?php if (!$error['check']['file_exists']): ?>
                                - File not found
                            <?php endif; ?>
                            <?php if (!$error['check']['web_accessible']): ?>
                                - Not web accessible
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="product-card">
            <h3>Recommendations</h3>
            <ul>
                <li>Ensure all image files are uploaded to <code>/upload/katalog-filter/</code></li>
                <li>Check file permissions (should be readable by web server)</li>
                <li>Verify that .htaccess allows access to image files</li>
                <li>Consider using shorter, URL-friendly filenames</li>
                <li>Optimize image sizes for web performance</li>
            </ul>
        </div>
    </div>
</body>
</html> 