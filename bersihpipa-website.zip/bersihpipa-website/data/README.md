# Struktur Data BersihPipa.com

Dokumentasi struktur data untuk sistem multi-kota BersihPipa.com

## Struktur Direktori

```
data/
├── data-master/          # Data master (cabang, kategori, dll)
├── produk/              # Data produk individual (struktur baru)
├── layanan/             # Data layanan (struktur lama - legacy)
├── items/               # Data item filter
├── pemesanan/           # Data pemesanan
├── video/               # Data video
└── README.md
```

## Struktur JSON Produk (Baru)

### Format File: `data/produk/{product-id}.json`

```json
{
  "id": "FA001",
  "nama": "Nama Produk",
  "slug": "slug-produk",
  "kategori": "filter-air",
  "deskripsi": "Deskripsi produk yang detail",
  "gambar": [
    "filter-air-premium-1.webp",
    "filter-air-premium-2.webp"
  ],
  "rating": 4.8,
  "terjual": 100,
  "fitur": [
    "Fitur 1",
    "Fitur 2",
    "Fitur 3"
  ],
  "spesifikasi": {
    "Kapasitas": "1000-1500 liter/jam",
    "Tekanan Kerja": "1-6 bar",
    "Suhu Operasi": "5-40°C",
    "Dimensi": "25cm x 150cm",
    "Garansi": "2 tahun"
  },
  "harga": {
    "malang": {
      "harga": 2095000,
      "harga_asli": 2500000,
      "diskon": 16,
      "satuan": "unit",
      "estimasi": "2-3 hari",
      "garansi": "2 tahun",
      "gratis_ongkir": true,
      "status": "tersedia"
    },
    "surabaya": {
      "harga": 2200000,
      "harga_asli": 2600000,
      "diskon": 15,
      "satuan": "unit",
      "estimasi": "2-3 hari",
      "garansi": "2 tahun",
      "gratis_ongkir": true,
      "status": "tersedia"
    }
  },
  "metadata": {
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-07-20T16:54:00Z",
    "version": "1.0.0"
  }
}
```

### Penjelasan Field Harga per Cabang:

- **harga**: Harga jual saat ini
- **harga_asli**: Harga sebelum diskon
- **diskon**: Persentase diskon (0-100)
- **satuan**: Satuan produk (unit, paket, meter, dll)
- **estimasi**: Estimasi waktu pengerjaan/pengiriman
- **garansi**: Periode garansi
- **gratis_ongkir**: Boolean untuk gratis ongkir
- **status**: Status ketersediaan (tersedia, tidak_tersedia, pre_order)

## Struktur Data Cabang

### Format File: `data/data-master/cabang.json`

```json
{
  "cabang": [
    {
      "id": "malang",
      "nama": "Kota Malang",
      "alamat": "Jl. Candi Mendut No 23B, Lowokwaru, Malang",
      "koordinat": {
        "lat": -7.9839,
        "lng": 112.6214
      },
      "kontak": {
        "telepon": "+6281236937200",
        "whatsapp": "+6281236937200",
        "email": "malang@bersihpipa.com"
      },
      "jam_operasional": {
        "senin_jumat": "08:00 - 17:00",
        "sabtu": "08:00 - 15:00",
        "minggu": "Tutup"
      },
      "services": {
        "pipa-mampet": { "price": 150000, "available": true },
        "filter-air": { "price": 300000, "available": true },
        "plumbing": { "price": 250000, "available": true }
      },
      "status": "aktif",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-07-20T16:54:00Z"
    }
  ],
  "metadata": {
    "total_cabang": 3,
    "cabang_aktif": 3,
    "last_updated": "2024-07-20T16:54:00Z",
    "version": "1.1.0"
  }
}
```

## Struktur Layanan (Legacy)

### Format File: `data/layanan/{layanan-id}.json`

Struktur ini masih didukung untuk backward compatibility, tetapi direkomendasikan untuk menggunakan struktur produk individual.

## Kategori Layanan

### Format File: `data/data-master/kategori-layanan.json`

```json
{
  "kategori": [
    {
      "id": "filter-air",
      "nama": "Filter Air",
      "deskripsi": "Pemasangan dan perawatan filter air",
      "icon": "/upload/icon/filter-air.svg",
      "status": "aktif"
    }
  ]
}
```

## Best Practices

### 1. Penamaan File
- Gunakan kebab-case untuk nama file
- Gunakan ID produk sebagai nama file utama
- Contoh: `paket-filter-air-premium.json`

### 2. ID Produk
- Gunakan format konsisten: `{KATEGORI}{NOMOR}`
- Contoh: `FA001` (Filter Air 001), `PM001` (Pipa Mampet 001)

### 3. Harga Multi-Kota
- Selalu sertakan harga untuk semua cabang aktif
- Gunakan fallback ke cabang default jika cabang tidak tersedia
- Update harga secara berkala

### 4. Gambar Produk
- Gunakan array untuk multiple images
- Sertakan gambar utama di index pertama
- Gunakan nama file saja (tanpa path): `"nama-file.webp"`
- ProductHelper akan otomatis menambahkan path `/upload/katalog-filter/`
- Format yang didukung: .webp, .jpg, .png
- Optimalkan ukuran gambar untuk performa web
- URL encoding otomatis untuk nama file dengan spasi

### 5. Metadata
- Selalu sertakan timestamp created_at dan updated_at
- Gunakan versioning untuk tracking perubahan
- Dokumentasikan perubahan besar

## Migration Guide

### Dari Struktur Lama ke Baru:

1. **Buat file produk individual** di `data/produk/`
2. **Pindahkan data produk** dari `data/layanan/` ke file individual
3. **Strukturkan harga per cabang** dalam object `harga`
4. **Update ProductHelper** untuk menggunakan struktur baru
5. **Test backward compatibility** dengan struktur lama

### Contoh Migration:

**Struktur Lama:**
```json
{
  "layanan": {
    "produk": {
      "filter_premium": {
        "id": "FA001",
        "nama": "Filter Premium"
      }
    },
    "cabang": {
      "malang": {
        "harga": {
          "filter_premium": { "harga": 850000 }
        }
      }
    }
  }
}
```

**Struktur Baru:**
```json
{
  "id": "FA001",
  "nama": "Filter Premium",
  "harga": {
    "malang": {
      "harga": 850000,
      "harga_asli": 1000000,
      "diskon": 15
    }
  }
}
```

## Validasi Data

### Checklist untuk Setiap Produk:

- [ ] ID produk unik dan konsisten
- [ ] Harga tersedia untuk semua cabang aktif
- [ ] Gambar produk valid dan accessible
- [ ] Metadata lengkap (created_at, updated_at, version)
- [ ] Spesifikasi produk lengkap
- [ ] Fitur produk terdaftar
- [ ] Status ketersediaan akurat

### Tools Validasi:

1. **JSON Schema Validator** untuk memastikan format benar
2. **Image URL Checker** untuk memastikan gambar accessible
3. **Price Consistency Checker** untuk memastikan harga logis
4. **Cabang Availability Checker** untuk memastikan semua cabang tercakup

## Troubleshooting

### Masalah Umum:

1. **Produk tidak muncul**: Cek ID produk dan kategori
2. **Harga tidak sesuai**: Cek struktur harga per cabang
3. **Gambar tidak load**: Cek URL gambar dan accessibility
4. **Cabang tidak tersedia**: Cek status cabang di data-master

### Debug Tips:

1. Gunakan `ProductHelper::getProductById()` untuk test
2. Cek log error untuk masalah JSON parsing
3. Validasi JSON format dengan online tools
4. Test dengan berbagai cabang untuk memastikan fallback bekerja 