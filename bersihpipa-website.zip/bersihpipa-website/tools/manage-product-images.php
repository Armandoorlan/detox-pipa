<?php
/**
 * Product Image Manager
 * Script untuk mengelola gambar produk dari folder katalog-filter
 */

class ProductImageManager {
    private $upload_path = '../upload/katalog-filter/';
    private $data_path = '../data/produk/';
    
    public function __construct() {
        if (!is_dir($this->upload_path)) {
            mkdir($this->upload_path, 0755, true);
        }
    }
    
    /**
     * Get all available images in katalog-filter folder
     */
    public function getAvailableImages() {
        $images = [];
        $files = glob($this->upload_path . '*.{webp,jpg,jpeg,png}', GLOB_BRACE);
        
        foreach ($files as $file) {
            $filename = basename($file);
            $images[] = [
                'filename' => $filename,
                'path' => '/upload/katalog-filter/' . $filename,
                'size' => filesize($file),
                'modified' => date('Y-m-d H:i:s', filemtime($file))
            ];
        }
        
        return $images;
    }
    
    /**
     * Get images used by products
     */
    public function getUsedImages() {
        $used_images = [];
        $product_files = glob($this->data_path . '*.json');
        
        foreach ($product_files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if ($data && isset($data['gambar']) && is_array($data['gambar'])) {
                foreach ($data['gambar'] as $image_path) {
                    $filename = basename($image_path);
                    $used_images[$filename] = [
                        'product_id' => $data['id'],
                        'product_name' => $data['nama'],
                        'path' => $image_path
                    ];
                }
            }
        }
        
        return $used_images;
    }
    
    /**
     * Get unused images
     */
    public function getUnusedImages() {
        $available = $this->getAvailableImages();
        $used = $this->getUsedImages();
        $unused = [];
        
        foreach ($available as $image) {
            if (!isset($used[$image['filename']])) {
                $unused[] = $image;
            }
        }
        
        return $unused;
    }
    
    /**
     * Update product images
     */
    public function updateProductImages($product_id, $images) {
        $file_path = $this->data_path . $product_id . '.json';
        
        if (!file_exists($file_path)) {
            return false;
        }
        
        $data = json_decode(file_get_contents($file_path), true);
        $data['gambar'] = $images;
        $data['metadata']['updated_at'] = date('c');
        
        return file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }
    
    /**
     * Generate image suggestions for products
     */
    public function suggestImagesForProduct($product_name) {
        $available = $this->getAvailableImages();
        $suggestions = [];
        
        // Simple keyword matching
        $keywords = strtolower($product_name);
        
        foreach ($available as $image) {
            $filename = strtolower($image['filename']);
            $score = 0;
            
            // Check for keyword matches
            if (strpos($filename, 'filter') !== false) $score += 2;
            if (strpos($filename, 'air') !== false) $score += 2;
            if (strpos($filename, 'sumur') !== false) $score += 1;
            if (strpos($filename, 'pure') !== false) $score += 1;
            if (strpos($filename, 'portable') !== false) $score += 1;
            
            if ($score > 0) {
                $suggestions[] = [
                    'image' => $image,
                    'score' => $score
                ];
            }
        }
        
        // Sort by score
        usort($suggestions, function($a, $b) {
            return $b['score'] - $a['score'];
        });
        
        return array_slice($suggestions, 0, 5); // Return top 5
    }
}

// CLI Usage
if (php_sapi_name() === 'cli') {
    $manager = new ProductImageManager();
    
    echo "=== Product Image Manager ===\n\n";
    
    // Show available images
    echo "Available Images:\n";
    $images = $manager->getAvailableImages();
    foreach ($images as $image) {
        echo "- {$image['filename']} ({$image['size']} bytes)\n";
    }
    
    echo "\nUsed Images:\n";
    $used = $manager->getUsedImages();
    foreach ($used as $filename => $info) {
        echo "- {$filename} (used by {$info['product_name']})\n";
    }
    
    echo "\nUnused Images:\n";
    $unused = $manager->getUnusedImages();
    foreach ($unused as $image) {
        echo "- {$image['filename']}\n";
    }
    
    echo "\n=== End ===\n";
}

// Web Interface
if (php_sapi_name() !== 'cli') {
    $manager = new ProductImageManager();
    
    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Product Image Manager</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
            .image-item { margin: 10px 0; padding: 10px; background: #f9f9f9; border-radius: 3px; }
            .unused { background: #fff3cd; }
            .used { background: #d1ecf1; }
        </style>
    </head>
    <body>
        <h1>Product Image Manager</h1>";
    
    // Available Images
    echo "<div class='section'>
        <h2>Available Images (" . count($manager->getAvailableImages()) . ")</h2>";
    foreach ($manager->getAvailableImages() as $image) {
        echo "<div class='image-item'>
            <strong>{$image['filename']}</strong><br>
            Size: " . number_format($image['size']) . " bytes<br>
            Modified: {$image['modified']}
        </div>";
    }
    echo "</div>";
    
    // Used Images
    echo "<div class='section'>
        <h2>Used Images (" . count($manager->getUsedImages()) . ")</h2>";
    foreach ($manager->getUsedImages() as $filename => $info) {
        echo "<div class='image-item used'>
            <strong>{$filename}</strong><br>
            Used by: {$info['product_name']} (ID: {$info['product_id']})
        </div>";
    }
    echo "</div>";
    
    // Unused Images
    echo "<div class='section'>
        <h2>Unused Images (" . count($manager->getUnusedImages()) . ")</h2>";
    foreach ($manager->getUnusedImages() as $image) {
        echo "<div class='image-item unused'>
            <strong>{$image['filename']}</strong><br>
            Size: " . number_format($image['size']) . " bytes
        </div>";
    }
    echo "</div>";
    
    echo "</body></html>";
}
?> 