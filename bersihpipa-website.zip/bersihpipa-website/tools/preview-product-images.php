<?php
/**
 * Product Image Preview
 * Script untuk preview gambar produk dari folder katalog-filter
 */

require_once '../includes/product-helper.php';

$helper = new ProductHelper();
$products = $helper->getProductsByLayanan('filter-air', 'malang');

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Image Preview - BersihPipa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .product-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .product-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .product-info {
            flex: 1;
        }
        .product-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .product-id {
            color: #666;
            font-size: 14px;
        }
        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .image-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            background: white;
        }
        .image-preview {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f0f0f0;
        }
        .image-info {
            padding: 10px;
            font-size: 12px;
            color: #666;
        }
        .image-path {
            word-break: break-all;
            margin-bottom: 5px;
        }
        .image-status {
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
        }
        .status-valid {
            background: #d4edda;
            color: #155724;
        }
        .status-invalid {
            background: #f8d7da;
            color: #721c24;
        }
        .status-missing {
            background: #fff3cd;
            color: #856404;
        }
        .summary {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .summary-item {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .summary-number {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }
        .summary-label {
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Product Image Preview - BersihPipa</h1>
        
        <?php
        $total_products = count($products);
        $total_images = 0;
        $valid_images = 0;
        $invalid_images = 0;
        $missing_images = 0;
        
        foreach ($products as $product) {
            $images = $helper->getProductImages($product);
            $total_images += count($images);
            
            foreach ($images as $image) {
                $image_path = $_SERVER['DOCUMENT_ROOT'] . $image;
                if (file_exists($image_path)) {
                    $valid_images++;
                } elseif ($image === '/placeholder.jpg') {
                    $missing_images++;
                } else {
                    $invalid_images++;
                }
            }
        }
        ?>
        
        <div class="summary">
            <h2>Summary</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-number"><?= $total_products ?></div>
                    <div class="summary-label">Total Products</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number"><?= $total_images ?></div>
                    <div class="summary-label">Total Images</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number"><?= $valid_images ?></div>
                    <div class="summary-label">Valid Images</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number"><?= $invalid_images ?></div>
                    <div class="summary-label">Invalid Images</div>
                </div>
                <div class="summary-item">
                    <div class="summary-number"><?= $missing_images ?></div>
                    <div class="summary-label">Missing Images</div>
                </div>
            </div>
        </div>
        
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <div class="product-header">
                    <div class="product-info">
                        <div class="product-title"><?= htmlspecialchars($product['nama']) ?></div>
                        <div class="product-id">ID: <?= $product['id'] ?></div>
                    </div>
                </div>
                
                <div class="image-grid">
                    <?php 
                    $images = $helper->getProductImages($product);
                    foreach ($images as $image): 
                        $image_path = $_SERVER['DOCUMENT_ROOT'] . $image;
                        $file_exists = file_exists($image_path);
                        $is_placeholder = $image === '/placeholder.jpg';
                        
                        if ($file_exists) {
                            $status_class = 'status-valid';
                            $status_text = 'Valid';
                        } elseif ($is_placeholder) {
                            $status_class = 'status-missing';
                            $status_text = 'Placeholder';
                        } else {
                            $status_class = 'status-invalid';
                            $status_text = 'Missing';
                        }
                    ?>
                        <div class="image-item">
                            <?php if ($file_exists && !$is_placeholder): ?>
                                <img src="<?= $image ?>" alt="<?= htmlspecialchars($product['nama']) ?>" class="image-preview">
                            <?php else: ?>
                                <div class="image-preview" style="display: flex; align-items: center; justify-content: center; color: #999;">
                                    <?= $is_placeholder ? 'Placeholder Image' : 'Image Not Found' ?>
                                </div>
                            <?php endif; ?>
                            <div class="image-info">
                                <div class="image-path"><?= htmlspecialchars($image) ?></div>
                                <span class="image-status <?= $status_class ?>"><?= $status_text ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="product-card">
            <h3>Available Images in /upload/katalog-filter/</h3>
            <div class="image-grid">
                <?php
                $upload_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/katalog-filter/';
                if (is_dir($upload_path)) {
                    $files = glob($upload_path . '*.{webp,jpg,jpeg,png}', GLOB_BRACE);
                    foreach ($files as $file) {
                        $filename = basename($file);
                        $web_path = '/upload/katalog-filter/' . $filename;
                        ?>
                        <div class="image-item">
                            <img src="<?= $web_path ?>" alt="<?= htmlspecialchars($filename) ?>" class="image-preview">
                            <div class="image-info">
                                <div class="image-path"><?= htmlspecialchars($filename) ?></div>
                                <span class="image-status status-valid">Available</span>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo '<p>Upload directory not found</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html> 