<?php
header('Content-Type: application/json');

// --- KONFIGURASI ---
$apiKey = 'AIzaSyB_X4gHY6vPXWxuaB33hCapS2VY66Xen6w'; // API Key Anda
$channelId = 'UC2sa9B3o7-fnDcMUFv-3u1Q'; // Channel ID untuk @fluksaqua
$maxResults = 15; // Jumlah video yang ingin diambil
$outputFile = __DIR__ . '/../data/video/youtube.json';

// --- FUNGSI BANTU ---

/**
 * Mengambil data dari URL menggunakan cURL.
 */
function fetchData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Nonaktifkan verifikasi SSL jika ada masalah
    $output = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code != 200) {
        return null;
    }
    return json_decode($output, true);
}

/**
 * Mengubah durasi ISO 8601 (misal: PT1M23S) menjadi total detik.
 */
function isoDurationToSeconds($iso_duration) {
    preg_match('/P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/', $iso_duration, $matches);
    $days = isset($matches[1]) ? (int)$matches[1] : 0;
    $hours = isset($matches[2]) ? (int)$matches[2] : 0;
    $minutes = isset($matches[3]) ? (int)$matches[3] : 0;
    $seconds = isset($matches[4]) ? (int)$matches[4] : 0;
    return ($days * 86400) + ($hours * 3600) + ($minutes * 60) + $seconds;
}

/**
 * Mengubah durasi ISO 8601 (misal: PT1M23S) menjadi format M:SS.
 */
function formatDuration($iso_duration) {
    $di = new DateInterval($iso_duration);
    $minutes = $di->i + ($di->h * 60);
    $seconds = $di->s;
    return sprintf("%d:%02d", $minutes, $seconds);
}

/**
 * Memformat angka penonton menjadi lebih ringkas (misal: 1.2K, 2M).
 */
function formatViews($views) {
    if ($views < 1000) {
        return $views;
    }
    if ($views < 1000000) {
        return round($views / 1000, 1) . 'K';
    }
    return round($views / 1000000, 1) . 'M';
}

// --- PROSES UTAMA ---

// 1. Ambil daftar video terbaru dari channel
$searchUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId={$channelId}&maxResults={$maxResults}&order=date&type=video&key={$apiKey}";
$searchResult = fetchData($searchUrl);

if (!$searchResult || empty($searchResult['items'])) {
    echo json_encode(['status' => 'error', 'message' => 'Gagal mengambil daftar video dari channel.', 'details' => $searchResult]);
    exit;
}

$videoIds = [];
foreach ($searchResult['items'] as $item) {
    $videoIds[] = $item['id']['videoId'];
}

// 2. Ambil detail untuk setiap video (durasi, penonton)
$videoDetailsUrl = "https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id=" . implode(',', $videoIds) . "&key={$apiKey}";
$videoDetailsResult = fetchData($videoDetailsUrl);

if (!$videoDetailsResult || empty($videoDetailsResult['items'])) {
    echo json_encode(['status' => 'error', 'message' => 'Gagal mengambil detail video.']);
    exit;
}

// 3. Gabungkan data dan format hasil akhir
$finalVideos = [];
$videoDetailsMap = [];
foreach ($videoDetailsResult['items'] as $item) {
    $videoDetailsMap[$item['id']] = $item;
}

foreach ($searchResult['items'] as $item) {
    $videoId = $item['id']['videoId'];
    $videoSnippet = $item['snippet'];
    $videoDetails = $videoDetailsMap[$videoId] ?? null;

    if ($videoDetails) {
        $finalVideos[] = [
            'id' => $videoId,
            'title' => $videoSnippet['title'],
            'duration' => formatDuration($videoDetails['contentDetails']['duration']),
            'views' => formatViews($videoDetails['statistics']['viewCount'])
        ];
    }
}

// 4. Simpan hasil ke file JSON
if (file_put_contents($outputFile, json_encode($finalVideos, JSON_PRETTY_PRINT))) {
    echo json_encode(['status' => 'success', 'message' => count($finalVideos) . ' video berhasil diambil dan disimpan ke ' . basename($outputFile)]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan file JSON.']);
}
