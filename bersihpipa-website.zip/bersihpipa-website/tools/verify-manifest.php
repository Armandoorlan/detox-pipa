<?php
/**
 * Manifest Verification Tool
 * Script untuk memverifikasi bahwa manifest.json dapat diakses
 */

function checkManifestAccess() {
    $manifest_path = '../manifest.json';
    $web_path = 'http://' . $_SERVER['HTTP_HOST'] . '/manifest.json';
    
    $file_exists = file_exists($manifest_path);
    $file_size = $file_exists ? filesize($manifest_path) : 0;
    
    // Check if manifest is accessible via web
    $headers = @get_headers($web_path);
    $web_accessible = $headers && strpos($headers[0], '200') !== false;
    
    // Check JSON validity
    $json_valid = false;
    $json_error = '';
    if ($file_exists) {
        $content = file_get_contents($manifest_path);
        $json_data = json_decode($content, true);
        $json_valid = json_last_error() === JSON_ERROR_NONE;
        if (!$json_valid) {
            $json_error = json_last_error_msg();
        }
    }
    
    return [
        'file_exists' => $file_exists,
        'file_size' => $file_size,
        'web_accessible' => $web_accessible,
        'json_valid' => $json_valid,
        'json_error' => $json_error,
        'web_path' => $web_path,
        'full_path' => realpath($manifest_path)
    ];
}

function checkIconAccess($manifest_data) {
    $icon_issues = [];
    
    if (isset($manifest_data['icons'])) {
        foreach ($manifest_data['icons'] as $index => $icon) {
            if (isset($icon['src'])) {
                $icon_path = $_SERVER['DOCUMENT_ROOT'] . $icon['src'];
                $icon_exists = file_exists($icon_path);
                
                if (!$icon_exists) {
                    $icon_issues[] = [
                        'type' => 'icon',
                        'index' => $index,
                        'src' => $icon['src'],
                        'issue' => 'File not found'
                    ];
                }
            }
        }
    }
    
    if (isset($manifest_data['shortcuts'])) {
        foreach ($manifest_data['shortcuts'] as $shortcut_index => $shortcut) {
            if (isset($shortcut['icons'])) {
                foreach ($shortcut['icons'] as $icon_index => $icon) {
                    if (isset($icon['src'])) {
                        $icon_path = $_SERVER['DOCUMENT_ROOT'] . $icon['src'];
                        $icon_exists = file_exists($icon_path);
                        
                        if (!$icon_exists) {
                            $icon_issues[] = [
                                'type' => 'shortcut_icon',
                                'shortcut_index' => $shortcut_index,
                                'icon_index' => $icon_index,
                                'src' => $icon['src'],
                                'issue' => 'File not found'
                            ];
                        }
                    }
                }
            }
        }
    }
    
    return $icon_issues;
}

$manifest_check = checkManifestAccess();
$manifest_data = null;

if ($manifest_check['file_exists'] && $manifest_check['json_valid']) {
    $manifest_data = json_decode(file_get_contents('../manifest.json'), true);
    $icon_issues = checkIconAccess($manifest_data);
} else {
    $icon_issues = [];
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manifest Verification - BersihPipa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .status-ok {
            border-left: 4px solid #28a745;
            background: #d4edda;
        }
        .status-error {
            border-left: 4px solid #dc3545;
            background: #f8d7da;
        }
        .status-warning {
            border-left: 4px solid #ffc107;
            background: #fff3cd;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin: 10px 0;
        }
        .info-item {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
            font-size: 12px;
        }
        .manifest-preview {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 10px 0;
            font-family: monospace;
            font-size: 12px;
            max-height: 400px;
            overflow-y: auto;
        }
        .issue-item {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 4px;
            padding: 10px;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manifest Verification Tool - BersihPipa</h1>
        
        <div class="card <?= $manifest_check['file_exists'] && $manifest_check['json_valid'] ? 'status-ok' : 'status-error' ?>">
            <h2>Manifest.json Status</h2>
            <div class="info-grid">
                <div class="info-item">
                    <strong>File Exists:</strong><br>
                    <?= $manifest_check['file_exists'] ? '✅ Yes' : '❌ No' ?>
                </div>
                <div class="info-item">
                    <strong>File Size:</strong><br>
                    <?= $manifest_check['file_size'] ? number_format($manifest_check['file_size']) . ' bytes' : 'N/A' ?>
                </div>
                <div class="info-item">
                    <strong>Web Accessible:</strong><br>
                    <?= $manifest_check['web_accessible'] ? '✅ Yes' : '❌ No' ?>
                </div>
                <div class="info-item">
                    <strong>JSON Valid:</strong><br>
                    <?= $manifest_check['json_valid'] ? '✅ Yes' : '❌ No' ?>
                </div>
            </div>
            
            <?php if (!$manifest_check['json_valid'] && $manifest_check['json_error']): ?>
                <div class="issue-item">
                    <strong>JSON Error:</strong> <?= htmlspecialchars($manifest_check['json_error']) ?>
                </div>
            <?php endif; ?>
            
            <div class="info-grid">
                <div class="info-item">
                    <strong>File Path:</strong><br>
                    <?= htmlspecialchars($manifest_check['full_path']) ?>
                </div>
                <div class="info-item">
                    <strong>Web URL:</strong><br>
                    <a href="<?= $manifest_check['web_path'] ?>" target="_blank"><?= $manifest_check['web_path'] ?></a>
                </div>
            </div>
        </div>
        
        <?php if ($manifest_data): ?>
            <div class="card">
                <h2>Manifest Content</h2>
                <div class="manifest-preview">
                    <pre><?= htmlspecialchars(json_encode($manifest_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>
                </div>
            </div>
            
            <div class="card">
                <h2>Manifest Properties</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <strong>Name:</strong><br>
                        <?= htmlspecialchars($manifest_data['name'] ?? 'N/A') ?>
                    </div>
                    <div class="info-item">
                        <strong>Short Name:</strong><br>
                        <?= htmlspecialchars($manifest_data['short_name'] ?? 'N/A') ?>
                    </div>
                    <div class="info-item">
                        <strong>Start URL:</strong><br>
                        <?= htmlspecialchars($manifest_data['start_url'] ?? 'N/A') ?>
                    </div>
                    <div class="info-item">
                        <strong>Display:</strong><br>
                        <?= htmlspecialchars($manifest_data['display'] ?? 'N/A') ?>
                    </div>
                    <div class="info-item">
                        <strong>Theme Color:</strong><br>
                        <?= htmlspecialchars($manifest_data['theme_color'] ?? 'N/A') ?>
                    </div>
                    <div class="info-item">
                        <strong>Background Color:</strong><br>
                        <?= htmlspecialchars($manifest_data['background_color'] ?? 'N/A') ?>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h2>Icons (<?= count($manifest_data['icons'] ?? []) ?>)</h2>
                <?php if (isset($manifest_data['icons'])): ?>
                    <div class="info-grid">
                        <?php foreach ($manifest_data['icons'] as $index => $icon): ?>
                            <div class="info-item">
                                <strong>Icon <?= $index + 1 ?>:</strong><br>
                                Src: <?= htmlspecialchars($icon['src'] ?? 'N/A') ?><br>
                                Sizes: <?= htmlspecialchars($icon['sizes'] ?? 'N/A') ?><br>
                                Type: <?= htmlspecialchars($icon['type'] ?? 'N/A') ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No icons defined</p>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($icon_issues)): ?>
                <div class="card status-warning">
                    <h2>Icon Issues (<?= count($icon_issues) ?>)</h2>
                    <?php foreach ($icon_issues as $issue): ?>
                        <div class="issue-item">
                            <strong><?= ucfirst($issue['type']) ?>:</strong><br>
                            Src: <?= htmlspecialchars($issue['src']) ?><br>
                            Issue: <?= htmlspecialchars($issue['issue']) ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div class="card">
            <h2>Recommendations</h2>
            <ul>
                <li>Ensure manifest.json is in the root directory</li>
                <li>Check file permissions (should be readable by web server)</li>
                <li>Verify that .htaccess allows access to JSON files</li>
                <li>Use local icon files instead of external URLs</li>
                <li>Test manifest with browser developer tools</li>
                <li>Validate JSON syntax with online tools</li>
            </ul>
        </div>
        
        <div class="card">
            <h2>Test Links</h2>
            <p><a href="/manifest.json" target="_blank">View manifest.json directly</a></p>
            <p><a href="https://www.pwabuilder.com/manifest" target="_blank">Validate with PWA Builder</a></p>
            <p><a href="https://jsonlint.com/" target="_blank">Validate JSON syntax</a></p>
        </div>
    </div>
</body>
</html> 