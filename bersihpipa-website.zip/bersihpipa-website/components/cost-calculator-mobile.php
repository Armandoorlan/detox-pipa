<?php
// Mobile Cost Calculator Component
?>
<div class="bg-white rounded-2xl shadow-modern border border-surface-100 overflow-hidden slide-in" data-section="hitung-biaya" id="hitung-biaya">
    <div class="p-4">
        <h3 class="text-sm font-semibold text-surface-900 mb-4 flex items-center">
                            <i data-lucide="calculator" class="w-4 h-4 mr-2 text-teal-500"></i>
            Hitung Biaya Detox Pipa
        </h3>
        
        <div class="space-y-4">
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-surface-700 mb-2">Jumlah Lantai</label>
                    <input type="number" id="lantai-mobile" placeholder="2" min="1" max="10" 
                           class="w-full px-3 py-2 border border-surface-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-surface-700 mb-2">Kamar Mandi</label>
                    <input type="number" id="kamarMandi-mobile" placeholder="3" min="1" max="20" 
                           class="w-full px-3 py-2 border border-surface-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-surface-700 mb-2">Jumlah Kran</label>
                    <input type="number" id="kran-mobile" placeholder="10" min="1" max="50" 
                           class="w-full px-3 py-2 border border-surface-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-surface-700 mb-2">Kota</label>
                    <select id="kota-mobile" class="w-full px-3 py-2 border border-surface-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Pilih Kota</option>
                        <option value="malang">Malang</option>
                        <option value="sidoarjo">Sidoarjo</option>
                        <option value="surabaya">Surabaya</option>
                        <option value="pasuruan">Pasuruan</option>
                        <option value="probolinggo">Probolinggo</option>
                        <option value="mojokerto">Mojokerto</option>
                        <option value="blitar">Blitar</option>
                        <option value="tulungagung">Tulungagung</option>
                    </select>
                </div>
            </div>

            <button onclick="calculateCostMobile()" 
                    class="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl active:scale-95">
                <i data-lucide="calculator" class="w-4 h-4 mr-2 inline"></i>
                Hitung Biaya
            </button>

            <!-- Result -->
            <div id="cost-result-mobile" class="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-4 text-center hidden">
                <div class="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                    <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
                </div>
                <h4 class="font-bold text-green-800 text-sm mb-2">Estimasi Biaya</h4>
                <p id="estimated-cost-mobile" class="text-2xl font-bold text-green-600 mb-2">Rp 0</p>
                <p class="text-xs text-green-700 mb-4">*Harga dapat berubah sesuai kondisi lapangan</p>
                <button onclick="costWhatsAppMobile()" 
                        class="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-semibold transition-all duration-300 active:scale-95">
                    <i data-lucide="message-circle" class="w-4 h-4 mr-2 inline"></i>
                    Konsultasi via WhatsApp
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let estimatedCostMobile = null;

function calculateCostMobile() {
    const lantai = document.getElementById('lantai-mobile').value;
    const kamarMandi = document.getElementById('kamarMandi-mobile').value;
    const kran = document.getElementById('kran-mobile').value;
    const kota = document.getElementById('kota-mobile').value;

    if (!lantai || !kamarMandi || !kran || !kota) {
        alert('Mohon lengkapi semua data yang diperlukan');
        return;
    }

    // Calculate cost: Number of faucets × Rp 150,000
    const totalKran = parseInt(kran);
    const baseCost = totalKran * 150000;
    const locationMultiplier = getLocationMultiplierMobile(kota);
    estimatedCostMobile = Math.round(baseCost * locationMultiplier);

    // Display result
    document.getElementById('estimated-cost-mobile').textContent = `Rp ${estimatedCostMobile.toLocaleString('id-ID')}`;
    document.getElementById('cost-result-mobile').classList.remove('hidden');
    
    // Scroll to result
    document.getElementById('cost-result-mobile').scrollIntoView({ behavior: 'smooth' });
}

function getLocationMultiplierMobile(city) {
    const multipliers = {
        'surabaya': 1.2,
        'sidoarjo': 1.1,
        'malang': 1.0,
        'pasuruan': 1.0,
        'probolinggo': 1.05,
        'mojokerto': 1.05,
        'blitar': 1.0,
        'tulungagung': 1.0
    };
    
    return multipliers[city] || 1.0;
}

function costWhatsAppMobile() {
    if (!estimatedCostMobile) return;
    
    const formData = {
        kota: document.getElementById('kota-mobile').value,
        lantai: document.getElementById('lantai-mobile').value,
        kamarMandi: document.getElementById('kamarMandi-mobile').value,
        kran: document.getElementById('kran-mobile').value
    };

    const message = `🏠 *KONSULTASI DETOX PIPA - FLUKS WATER TREATMENT*

📍 *Kota:* ${formData.kota.charAt(0).toUpperCase() + formData.kota.slice(1)}
🏠 *Jumlah Lantai:* ${formData.lantai}
🚿 *Kamar Mandi:* ${formData.kamarMandi}
🚰 *Jumlah Kran:* ${formData.kran}
💰 *Estimasi Biaya:* Rp ${estimatedCostMobile.toLocaleString('id-ID')}

📱 Dikirim dari: BersihPipa.com PWA

Mohon info lebih lanjut untuk layanan detox pipa. Terima kasih! 🙏`;

    const whatsappUrl = `https://wa.me/6281236937200?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Make functions globally available
window.calculateCostMobile = calculateCostMobile;
window.costWhatsAppMobile = costWhatsAppMobile;
</script>
